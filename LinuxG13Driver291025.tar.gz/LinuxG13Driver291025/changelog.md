# Changelog

All notable changes to this project will be documented in this file.

## [2.0.0] - 2025-10-18

### Added
- **Automatic driver restart with user confirmation** - After saving profiles, users are prompted to restart the driver to apply changes
- **Auto-save functionality** - All key binding changes save immediately without manual intervention
- **Panel synchronization** - MacroEditorPanel and KeybindPanel now properly communicate and stay in sync
- **Comprehensive debug logging** - Full instrumentation for troubleshooting
- **200 macro slots** - All macro slots now properly accessible and functional
- **Desktop launcher** - Optional .desktop file for easy GUI access from application menu
- **Installation script** - Automated setup script for streamlined installation

### Fixed
- **Critical: loadingData flag timing bug** - Fixed the race condition where `loadingData` was set to `false` after the save attempt, causing all key selections to fail saving
- **Critical: Panel sync doesn't save** - MacroEditorPanel → KeybindPanel synchronization now properly saves the selected macro
- **Macro dropdown disabled state** - Dropdown now stays enabled, only editing controls are disabled for read-only macros (0-15)
- **No user feedback for driver restart** - Users now get clear confirmation dialogs when saving and restarting the driver
- **Off-by-one key indexing** - Documented the G0-G21 internal vs G1-G22 physical labeling (GUI handles this automatically)

### Changed
- **Improved error handling** - Better error messages with actionable troubleshooting steps
- **Enhanced UI feedback** - Clear visual indicators for save states and driver status
- **Optimized save logic** - Eliminated redundant save operations while ensuring all user changes persist

### Technical Details

#### Bug Fix #1: loadingData Flag (KeybindPanel.java)
**Before:**
```java
public void setSelectedKey(final Key key) {
    loadingData = true;
    // ... load UI controls ...
    updateComponentStateAndSave();  // ← Blocked by loadingData=true
    loadingData = false;           // ← Too late!
}
```

**After:**
```java
public void setSelectedKey(final Key key) {
    loadingData = true;
    // ... load UI controls ...
    loadingData = false;           // ← Set false BEFORE save
    saveBindings();                // ← Now it works!
}
```

#### Bug Fix #2: Panel Synchronization (KeybindPanel.java)
**Before:**
```java
public void setSelectedMacro(int macroIndex) {
    loadingData = true;
    macroSelectionBox.setSelectedIndex(macroIndex);
    loadingData = false;
    // No save - user selections lost!
}
```

**After:**
```java
public void setSelectedMacro(int macroIndex) {
    loadingData = true;
    macroSelectionBox.setSelectedIndex(macroIndex);
    loadingData = false;
    saveBindings();  // ← Actually save the user's choice!
}
```

#### Feature #1: Automatic Driver Restart (MacroEditorPanel.java)
```java
private void restartDriver() {
    ProcessBuilder pb = new ProcessBuilder("systemctl", "--user", "restart", "g13-driver.service");
    Process p = pb.start();
    int exitCode = p.waitFor();
    // Show success/failure dialog
}
```

### Known Issues
- **Off-by-one indexing**: Physical keys labeled G1-G22 are internally G0-G21. This is a hardware limitation, not a bug. The GUI handles this automatically.
- **Ayatana requirement**: Must compile with `libayatana-appindicator3-dev` on modern Ubuntu/Debian systems or tray icon won't appear

### Upgrade Notes
If upgrading from LordBooker's original fork:
1. Back up your `~/.g13/` directory
2. Rebuild both driver and GUI
3. Restart the systemd service
4. Your existing key bindings and macros will be preserved

---

## [1.0.0] - Original LordBooker Fork

### Features
- Basic GUI for configuration
- Macro recording
- 4 binding profiles (M1, M2, M3, MR)
- Ayatana AppIndicator support
- Systemd service integration

### Known Bugs (Fixed in 2.0.0)
- Key selections don't save automatically
- Macro panel doesn't sync properly
- No indication that driver needs restart
- Macro dropdown gets stuck disabled

---

## Credits

### Version 2.0.0 Contributors
- **Dominik** - Major bug fixes, auto-restart feature, comprehensive testing

### Original Authors
- **ecraven** - Original Linux G13 driver
- **LordBooker** - GUI implementation, Ayatana support
- **Community contributors** - Various fixes and improvements

---

## Testing

### Tested Configurations

#### Version 2.0.0
- **OS**: Ubuntu Studio 24.04
- **Desktop**: KDE Plasma 5.27.12
- **Kernel**: 6.8.0-83-lowlatency
- **Java**: OpenJDK 17
- **Maven**: 3.8.7
- **Hardware**: Logitech G13 Advanced Gameboard

#### Expected to Work
- Ubuntu 22.04 LTS and newer
- Debian 12 and newer
- Fedora 38+
- Arch Linux (current)
- Any systemd-based distribution with modern desktop environment

---

## Future Improvements

### Planned
- [ ] Remove debug logging for production release
- [ ] Add configuration import/export
- [ ] Profile management (rename, duplicate)
- [ ] Macro library/sharing
- [ ] On-screen display for active profile
- [ ] Game-specific profile auto-switching
- [ ] LCD display support improvements

### Under Consideration
- [ ] Wayland support improvements
- [ ] Flatpak packaging
- [ ] AUR package for Arch Linux
- [ ] Windows cross-compilation (via WSL)

---

## How to Report Bugs

1. Check existing GitHub issues
2. Verify you're using the latest version
3. Include:
   - Linux distribution and version
   - Desktop environment
   - Driver logs: `journalctl --user -u g13-driver -n 50`
   - Steps to reproduce
4. Use GitHub issue templates

---

## Version Numbering

This project uses [Semantic Versioning](https://semver.org/):
- **MAJOR**: Incompatible API changes
- **MINOR**: New functionality (backwards compatible)
- **PATCH**: Bug fixes (backwards compatible)

Current: **2.0.0** - Major rewrite with bug fixes and new features
