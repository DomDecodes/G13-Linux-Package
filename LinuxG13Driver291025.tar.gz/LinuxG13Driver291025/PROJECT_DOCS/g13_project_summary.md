# Logitech G13 Linux Driver - Complete Project Summary

**Date:** October 17, 2025  
**Status:** Working driver, GUI needs macro selector replacement  
**OS:** Ubuntu Studio 24.04, KDE Plasma 5.27.12

---

## ✅ WHAT'S WORKING

### Hardware & Driver
- ✅ **Driver runs automatically on boot** via systemd user service
- ✅ **All 22 G-keys detected** (G1-G22) via evdev
- ✅ **4 profile switching works** (M1-M4 buttons with color coding)
  - M1 = Red background
  - M2 = Green background  
  - M3 = Blue background
  - M4 = White background
- ✅ **Direct key bindings work** (format: `p,k.X` in config files)
- ✅ **Macro playback works** (can assign existing macros to keys)
- ✅ **Manual macro creation works** (by editing .properties files)
- ✅ **All 200 macro slots exist** (macro-0.properties through macro-199.properties)

### GUI Functionality
- ✅ GUI launches and displays G13 layout
- ✅ Can select keys and assign existing macros
- ✅ Profile color picker works
- ✅ Can view macro contents
- ✅ Macro files load correctly (all 200 slots with proper IDs)

---

## ❌ WHAT'S NOT WORKING

### Critical Issue: Macro Recorder Disabled
**Problem:** The "Clear & Record" button stays grayed out for macro slots 16-199

**Root Cause Discovered:**
1. The dropdown `macroSelectionBox.getSelectedIndex()` **always returns 0** regardless of what's visually selected
2. When user clicks macro 18, no `ActionListener` event fires (nothing prints to debug terminal)
3. The dropdown appears unresponsive - no hover highlighting, no "clicky" feedback
4. This causes `canModifyMacro()` to always see `selectedIndex=0`, making `result=false` for non-editable slots

**Why This Breaks Recording:**
- `canModifyMacro()` checks if `selectedIndex >= 16` (user-editable range)
- Since it always sees index 0, it always returns `false`
- This disables the recorder button via `recordButton.setEnabled(canModifyMacro())`

### Minor Issues
- ❌ Left-click on joystick is flaky (hardware issue, not driver)
- ⚠️ Off-by-one bug: Physical G1 = G0 in config files (documented in G13.cpp)

---

## 🗂️ FILE LOCATIONS

### Driver Files
```
~/src/linux-g13-driver/
├── g13-driver/
│   ├── Linux-G13-Driver          # Compiled binary
│   ├── Linux-G13-GUI.jar         # GUI application
│   └── src/cpp/G13.cpp           # Driver source (has off-by-one bug comment)
└── g13-config-tool/
    └── src/main/java/com/booker/g13/
        ├── MacroEditorPanel.java # Line ~207: canModifyMacro() method
        ├── Configs.java          # Line 59: DEFAULT_MACROS_COUNT = 16
        └── [other Java files]
```

### Configuration Files
```
~/.g13/
├── bindings-0.properties         # M1 profile keybindings
├── bindings-1.properties         # M2 profile keybindings
├── bindings-2.properties         # M3 profile keybindings
├── bindings-3.properties         # M4 profile keybindings
├── macro-0.properties            # Macro slot 0 (CTRL-ALT-DEL)
├── macro-1.properties            # Macro slot 1 (CTRL_A - custom)
├── ...
└── macro-199.properties          # All 200 slots exist with correct IDs
```

### System Files
```
~/.config/systemd/user/g13-driver.service    # Auto-start service
~/.local/share/applications/g13-*.desktop    # Menu entries
```

---

## 🔧 KEY CODE DISCOVERIES

### 1. The canModifyMacro() Logic
**Location:** `MacroEditorPanel.java` line ~207

```java
private boolean canModifyMacro() {
    int selectedIndex = macroSelectionBox.getSelectedIndex();
    int defaultCount = Configs.DEFAULT_MACROS_COUNT;
    boolean result = selectedIndex >= defaultCount;
    
    // DEBUG output added
    System.out.println("DEBUG canModifyMacro: selectedIndex=" + selectedIndex + 
                       ", DEFAULT_MACROS_COUNT=" + defaultCount + 
                       ", result=" + result);
    
    return result;
}
```

**Intent:** Slots 0-15 are "preset macros" (read-only), slots 16-199 are user-editable

**Problem:** `selectedIndex` always equals 0, so result is always `false`

### 2. The Dropdown Action Listener
**Location:** `MacroEditorPanel.java` line ~102

```java
macroSelectionBox.addActionListener(e -> {
    System.out.println("DEBUG: Dropdown changed, calling selectMacro()");
    if (loadingData) {
        System.out.println("DEBUG: Ignoring change - still loading data");
        return;
    }
    selectMacro();
});
```

**Problem:** This listener fires during initial load but **NOT when user manually changes selection**

### 3. The setMacros() Method
**Location:** `MacroEditorPanel.java` line ~295

```java
public void setMacros(final Properties[] macros) {
    loadingData = true;
    macroSelectionBox.removeAllItems();
    System.out.println("DEBUG setMacros: Adding " + macros.length + " macros to dropdown");
    for (final Properties properties : macros) {
        System.out.println("DEBUG: Adding macro id=" + properties.getProperty("id") + 
                           ", name=" + properties.getProperty("name"));
        macroSelectionBox.addItem(properties);
    }
    // ... rest of method
}
```

**Confirmed:** All 200 macros load correctly with proper IDs (0-199)

---

## 🐛 DEBUG OUTPUT ANALYSIS

### Startup Sequence (Normal)
```
DEBUG canModifyMacro: selectedIndex=-1, DEFAULT_MACROS_COUNT=16, result=false
DEBUG setMacros: Adding 200 macros to dropdown
DEBUG: Adding macro id=0, name=CTRL-ALT-DEL
DEBUG: Adding macro id=1, name=CTRL_A
...
DEBUG: Adding macro id=199, name=
DEBUG: Dropdown changed, calling selectMacro()
DEBUG selectMacro called: loadingData=false, selectedItem={..., id=0}, selectedIndex=0
```

### User Selects Macro 18 (Broken Behavior)
```
[NO OUTPUT - ActionListener doesn't fire]
[Dropdown visually shows "18" but no debug prints]
[selectedIndex remains 0 internally]
```

**Expected behavior:** Should print "Dropdown changed" and show `selectedIndex=18`

**Actual behavior:** Complete silence, no event fires

---

## 🎯 PROPOSED SOLUTION: Replace Dropdown with Grid Dialog

### Current UX Problem
- 200 items in a dropdown is poor UX
- Dropdown is unresponsive (no hover effects, no click feedback)
- Selection events don't fire properly

### New Design: File Explorer Style Grid

```
┌────────────────────────────────────────────────┐
│ Select Macro                              [×]  │
├────────────────────────────────────────────────┤
│ [Select] [Edit Macro] [Cancel]                 │ ← Top toolbar
├────────────────────────────────────────────────┤
│ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ │
│ │ [0]  │ │ [1]  │ │ [2]  │ │ [3]  │ │ [4]  │ │
│ │CTRL- │ │CTRL_A│ │SHIFT-│ │ALT-F4│ │ALT-F5│ │
│ │ALT-  │ │      │ │ALT-  │ │      │ │      │ │
│ │ DEL  │ │      │ │ TAB  │ │      │ │      │ │
│ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ │
│ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ │
│ │ [5]  │ │ [6]  │ │ [7]  │ │ [8]  │ │ [9]  │ │
│ │ALT-F6│ │ALT-F7│ │ALT-F8│ │ALT-F9│ │ALT-  │ │
│ │      │ │      │ │      │ │      │ │ F10  │ │
│ │      │ │      │ │      │ │      │ │      │ │
│ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ │
│                                                │
│        [Scrollable - 40 rows of 5 columns]    │
│                                                │
└────────────────────────────────────────────────┘
```

### Specifications
- **Grid Layout:** 5 columns × 40 rows (200 total cells)
- **Scrollable:** Vertical scroll for all 200 macros
- **Cell Format:** `[ID]\nName` or `[ID]\nEmpty`
- **Selection:** Click to select (highlight border), double-click to quick-select
- **Buttons:**
  - **Select:** Assigns macro to current G-key, closes dialog
  - **Edit Macro:** Opens macro recorder for selected slot
  - **Cancel:** Closes without changes

### Implementation Steps

#### 1. Create New Dialog Class
**File:** `~/src/linux-g13-driver/g13-config-tool/src/main/java/com/booker/g13/MacroSelectionDialog.java`

```java
public class MacroSelectionDialog extends JDialog {
    private int selectedMacroId = -1;
    private boolean shouldEdit = false;
    
    public MacroSelectionDialog(Frame parent, Properties[] macros, int currentMacroId) {
        // Constructor: Set up dialog
    }
    
    public int getSelectedMacroId() {
        return selectedMacroId;
    }
    
    public boolean shouldEditMacro() {
        return shouldEdit;
    }
}
```

#### 2. Create Grid Panel Component

```java
private JPanel createMacroGrid(Properties[] macros) {
    JPanel gridPanel = new JPanel(new GridLayout(40, 5, 5, 5));
    
    for (int i = 0; i < 200; i++) {
        Properties macro = macros[i];
        JButton macroButton = new JButton();
        
        // Format: "[ID]\nName"
        String id = macro.getProperty("id");
        String name = macro.getProperty("name");
        if (name == null || name.isEmpty()) {
            name = "Empty";
        }
        macroButton.setText("<html>[" + id + "]<br>" + name + "</html>");
        
        // Click handler
        final int macroId = i;
        macroButton.addActionListener(e -> selectMacro(macroId));
        
        // Double-click handler for quick select
        macroButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    selectedMacroId = macroId;
                    shouldEdit = false;
                    dispose();
                }
            }
        });
        
        gridPanel.add(macroButton);
    }
    
    return new JScrollPane(gridPanel);
}
```

#### 3. Modify MacroEditorPanel.java

**Replace dropdown with button:**

```java
// OLD: private JComboBox<Properties> macroSelectionBox;
// NEW:
private JButton macroSelectorButton;
private int currentMacroId = 0;

private void setupUI() {
    // ... other setup ...
    
    macroSelectorButton = new JButton("Macro: [0] CTRL-ALT-DEL");
    macroSelectorButton.addActionListener(e -> openMacroSelectionDialog());
    
    northPanel.add(macroSelectorButton, BorderLayout.NORTH);
    // ... rest of setup ...
}

private void openMacroSelectionDialog() {
    MacroSelectionDialog dialog = new MacroSelectionDialog(
        getParentFrame(), 
        allMacros, 
        currentMacroId
    );
    dialog.setVisible(true);
    
    if (dialog.getSelectedMacroId() >= 0) {
        currentMacroId = dialog.getSelectedMacroId();
        
        if (dialog.shouldEditMacro()) {
            // Open macro editor for this slot
            loadMacroForEditing(currentMacroId);
        } else {
            // Just select this macro (assign to key)
            assignMacroToCurrentKey(currentMacroId);
        }
        
        updateMacroButton();
    }
}

private void updateMacroButton() {
    Properties macro = allMacros[currentMacroId];
    String name = macro.getProperty("name");
    if (name == null || name.isEmpty()) {
        name = "Empty";
    }
    macroSelectorButton.setText("Macro: [" + currentMacroId + "] " + name);
}
```

#### 4. Reference: Color Picker Dialog Pattern

Look at existing dialog code in the GUI to follow the same pattern. Search for:

```bash
grep -r "JDialog\|extends Dialog" ~/src/linux-g13-driver/g13-config-tool/src/
```

This will show how the color picker dialog is implemented - use the same structure.

---

## 🔨 BUILD & TEST COMMANDS

### Rebuild GUI
```bash
cd ~/src/linux-g13-driver/g13-config-tool
mvn clean package
cp target/Linux-G13-GUI.jar ~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar
```

### Test with Debug Output
```bash
cd ~/src/linux-g13-driver/g13-driver
java -jar Linux-G13-GUI.jar
```

### Restart Driver
```bash
systemctl --user restart g13-driver
```

### Check Driver Status
```bash
systemctl --user status g13-driver
```

---

## 📝 WORKAROUNDS (Current Manual Methods)

### Create/Edit Macros Manually

**1. Create a new macro file:**
```bash
nano ~/.g13/macro-50.properties
```

**2. Add content:**
```properties
#Custom Macro
sequence=kd.29,kd.30,ku.30,ku.29
name=CTRL+A
id=50
```

**3. Assign to a key in profile:**
```bash
nano ~/.g13/bindings-0.properties
```

**4. Add line (remember: Physical G2 = G1 in config):**
```
p,k.1=m.50
```

**5. Restart driver:**
```bash
systemctl --user restart g13-driver
```

### Key Code Format
- **Direct key binding:** `p,k.X=KEY_NAME` (e.g., `p,k.0=KEY_A`)
- **Macro binding:** `p,k.X=m.Y` (e.g., `p,k.1=m.50`)
- **Macro sequence format:** `kd.CODE,ku.CODE,d.MILLISECONDS`
  - `kd` = key down
  - `ku` = key up
  - `d` = delay

---

## 🚀 NEXT SESSION PRIORITIES

### Option A: Fix Dropdown (Higher Risk)
1. Investigate why ActionListener doesn't fire on manual selection
2. Check if dropdown is being disabled somewhere
3. Look for custom cell renderer issues
4. Debug focus/event consumption

### Option B: Replace with Grid Dialog (Recommended)
1. ✅ **Study color picker dialog code** for pattern reference
2. ✅ **Create MacroSelectionDialog.java** with grid layout
3. ✅ **Replace dropdown in MacroEditorPanel.java** with button
4. ✅ **Test selection and assignment**
5. ✅ **Add "Edit Macro" functionality**
6. ✅ **Remove all dropdown-related code**

**Recommendation:** Option B is cleaner, better UX, and avoids debugging broken component

---

## 📚 USEFUL REFERENCES

### Java Swing Components Needed
- `JDialog` - For popup window
- `JPanel` with `GridLayout(40, 5)` - For 5-column grid
- `JScrollPane` - To make grid scrollable
- `JButton` - For each macro cell and action buttons
- `MouseAdapter` - For double-click detection

### Key Methods to Implement
```java
// In MacroSelectionDialog
private void selectMacro(int id)          // Highlights selected macro
private void onSelectClicked()            // "Select" button handler
private void onEditClicked()              // "Edit Macro" button handler
private void onCancelClicked()            // "Cancel" button handler

// In MacroEditorPanel
private void openMacroSelectionDialog()   // Opens dialog, handles result
private void loadMacroForEditing(int id)  // Loads macro into editor
private void assignMacroToCurrentKey(int id) // Assigns to G-key
private void updateMacroButton()          // Updates button text
```

---

## 🎓 WHAT WE LEARNED

### Debug Discoveries
1. **Properties objects load correctly** - All 200 macros with proper IDs
2. **Files are perfect** - ~/.g13/macro-X.properties all have correct data
3. **setMacros() works** - Dropdown gets populated correctly
4. **ActionListener only fires on init** - Not on manual user selection
5. **getSelectedIndex() always returns 0** - Even when visually shows 18

### Why Standard Debugging Failed
- Adding debug output revealed the dropdown events simply don't fire
- The component appears fundamentally broken or misconfigured
- Easier to replace than fix

### UI/UX Insights
- 200 items in dropdown = terrible user experience
- Grid/gallery view = familiar pattern (file explorer)
- Separate "Select" and "Edit" actions = clearer workflow

---

## 📋 HANDOFF CHECKLIST

### For Next Session
- [ ] Upload this document to project folder
- [ ] Upload `MacroEditorPanel.java` (current state with debug code)
- [ ] Upload `Configs.java` 
- [ ] Upload sample macro files (macro-0, macro-16, macro-50)
- [ ] Upload `bindings-0.properties` example
- [ ] Note current `DEFAULT_MACROS_COUNT = 16` setting
- [ ] Provide directory tree of project structure

### Files to Share
```bash
~/src/linux-g13-driver/PROJECT_DOCS/
├── MacroEditorPanel.java          # Current state
├── Configs.java                   # Config constants
├── G13.cpp                         # Driver source (for reference)
├── g13-driver.service             # Systemd service
├── bindings-0.properties          # Example profile
├── macro-0.properties             # Example preset macro
├── macro-16.properties            # Example empty macro
├── directory_structure.txt        # Full tree
└── PROJECT_SUMMARY.md             # This document
```

---

## 🎯 SUCCESS CRITERIA

The project will be complete when:
- ✅ User can browse all 200 macro slots easily
- ✅ User can select any macro and assign it to a G-key
- ✅ User can click "Edit Macro" to record/modify any slot 0-199
- ✅ Macro recorder works for all slots (no grayed-out button)
- ✅ Changes save to .properties files correctly
- ✅ Driver picks up changes and executes macros

---

**End of Summary**  
*Ready for handoff to new session*