#!/bin/bash

# Logitech G13 Linux Driver Installation Script
# Supports: Ubuntu, Debian, KDE Neon, Arch Linux, Fedora, and derivatives

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Symbols
CHECK="${GREEN}✓${NC}"
ARROW="${BLUE}▶${NC}"
WARN="${YELLOW}⚠${NC}"
ERROR="${RED}✗${NC}"

# Print colored message
print_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e " $1"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
}

print_step() {
    echo -e "${ARROW} $1"
}

print_success() {
    echo -e "${CHECK} $1"
}

print_warning() {
    echo -e "${WARN} $1"
}

print_error() {
    echo -e "${ERROR} $1"
}

# Detect Linux distribution
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
        VERSION=$VERSION_ID
        PRETTY_NAME=$PRETTY_NAME
    else
        print_error "Cannot detect Linux distribution"
        exit 1
    fi
}

# Install dependencies based on distribution
install_dependencies() {
    print_step "Installing dependencies..."
    
    case "$DISTRO" in
        ubuntu|debian|neon|pop|linuxmint|elementary)
            print_success "Detected Debian/Ubuntu-based system: $PRETTY_NAME"
            sudo apt update
            sudo apt install -y \
                build-essential \
                libusb-1.0-0-dev \
                openjdk-17-jdk \
                maven \
                libayatana-appindicator3-dev \
                git \
                pkg-config
            ;;
        
        arch|manjaro|endeavouros)
            print_success "Detected Arch-based system: $PRETTY_NAME"
            sudo pacman -Syu --needed --noconfirm \
                base-devel \
                libusb \
                jdk-openjdk \
                maven \
                libayatana-appindicator \
                git \
                pkg-config
            ;;
        
        fedora|rhel|centos|rocky|almalinux)
            print_success "Detected Red Hat-based system: $PRETTY_NAME"
            sudo dnf install -y \
                gcc-c++ \
                make \
                libusb1-devel \
                java-17-openjdk-devel \
                maven \
                libayatana-appindicator-gtk3-devel \
                git \
                pkgconfig
            ;;
        
        opensuse*|suse)
            print_success "Detected openSUSE: $PRETTY_NAME"
            sudo zypper install -y \
                gcc-c++ \
                make \
                libusb-1_0-devel \
                java-17-openjdk-devel \
                maven \
                libayatana-appindicator3-devel \
                git \
                pkg-config
            ;;
        
        *)
            print_warning "Unsupported distribution: $DISTRO"
            print_warning "Please install dependencies manually:"
            echo "  - build-essential / base-devel"
            echo "  - libusb-1.0-dev"
            echo "  - openjdk-17-jdk (or newer)"
            echo "  - maven"
            echo "  - libayatana-appindicator3-dev"
            echo "  - git"
            echo "  - pkg-config"
            read -p "Press Enter when dependencies are installed..."
            ;;
    esac
    
    print_success "Dependencies installed"
}

# Build the C++ driver
build_driver() {
    print_step "Building G13 driver..."
    
    cd g13-driver/src
    
    if [ ! -f Makefile ]; then
        print_error "Makefile not found in g13-driver/src"
        exit 1
    fi
    
    make clean || true
    make
    
    if [ ! -f ../Linux-G13-Driver ]; then
        print_error "Driver binary not created"
        exit 1
    fi
    
    print_success "Driver built successfully"
    cd ../..
}

# Build the Java GUI
build_gui() {
    print_step "Building Java GUI..."
    
    cd g13-config-tool
    
    if [ ! -f pom.xml ]; then
        print_error "pom.xml not found in g13-config-tool"
        exit 1
    fi
    
    mvn clean package
    
    if [ ! -f target/Linux-G13-GUI.jar ]; then
        print_error "GUI JAR not created"
        exit 1
    fi
    
    # Copy JAR to driver directory
    cp target/Linux-G13-GUI.jar ../g13-driver/
    
    print_success "GUI built successfully"
    cd ..
}

# Setup udev rules
setup_udev() {
    print_step "Setting up udev rules..."
    
    # Add user to plugdev group if it exists
    if getent group plugdev > /dev/null; then
        sudo usermod -a -G plugdev $USER
        print_success "Added $USER to plugdev group"
    fi
    
    # Copy udev rules
    if [ -f g13-driver/src/udev/99-g13-plugdev.rules ]; then
        sudo cp g13-driver/src/udev/99-g13-plugdev.rules /etc/udev/rules.d/
        print_success "Installed udev rules"
    else
        print_warning "udev rules file not found, skipping"
    fi
    
    # Reload udev rules
    sudo udevadm control --reload-rules
    sudo udevadm trigger
    
    print_success "udev rules configured"
}

# Create configuration directory
setup_config_dir() {
    print_step "Creating configuration directory..."
    
    CONFIG_DIR="$HOME/.g13"
    if [ ! -d "$CONFIG_DIR" ]; then
        mkdir -p "$CONFIG_DIR"
        print_success "Created $CONFIG_DIR"
    else
        print_success "Configuration directory already exists"
    fi
}

# Create desktop entry for GUI
create_desktop_entry() {
    print_step "Creating desktop entry..."
    
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    DESKTOP_DIR="$HOME/.local/share/applications"
    
    mkdir -p "$DESKTOP_DIR"
    
    cat > "$DESKTOP_DIR/g13-config.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=G13 Configuration
Comment=Configure Logitech G13 Gamepad
Exec=java -jar $SCRIPT_DIR/g13-driver/Linux-G13-GUI.jar
Icon=input-gaming
Terminal=false
Categories=Settings;HardwareSettings;
Keywords=logitech;g13;gamepad;macro;
EOF
    
    chmod +x "$DESKTOP_DIR/g13-config.desktop"
    
    # Update desktop database if available
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$DESKTOP_DIR"
    fi
    
    print_success "Desktop entry created"
}

# Setup systemd service
setup_systemd() {
    print_step "Setting up systemd service..."
    
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    SERVICE_DIR="$HOME/.config/systemd/user"
    
    mkdir -p "$SERVICE_DIR"
    
    cat > "$SERVICE_DIR/g13-driver.service" << EOF
[Unit]
Description=Logitech G13 Driver
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=$SCRIPT_DIR/g13-driver
ExecStart=$SCRIPT_DIR/g13-driver/Linux-G13-Driver
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF
    
    print_success "Created systemd service"
    
    # Reload systemd and enable service
    systemctl --user daemon-reload
    systemctl --user enable g13-driver.service
    
    print_success "Systemd service enabled"
    
    # Try to start the service now
    print_step "Starting G13 driver service..."
    if systemctl --user start g13-driver.service; then
        sleep 2
        if systemctl --user is-active --quiet g13-driver.service; then
            print_success "Driver service started successfully"
        else
            print_warning "Driver service failed to start - check logs with: journalctl --user -u g13-driver -n 50"
        fi
    else
        print_warning "Could not start service now - will start after reboot"
    fi
}

# Check for tray icon support
check_tray_icon() {
    print_step "Checking for system tray icon support..."
    
    # Check if the driver binary has Ayatana support compiled in
    if strings g13-driver/Linux-G13-Driver | grep -q "ayatana\|appindicator"; then
        print_success "Tray icon support detected in driver"
    else
        print_warning "Tray icon support NOT detected in driver binary"
        print_warning "The driver may need to be recompiled with Ayatana AppIndicator support"
        echo "  To enable tray icon, ensure the source includes Ayatana patch before building"
    fi
    
    # Check if ayatana libraries are available on the system
    if ldconfig -p | grep -q "libayatana-appindicator3"; then
        print_success "Ayatana AppIndicator library found on system"
    else
        print_warning "Ayatana AppIndicator library not found - tray icon may not work"
    fi
}

# Main installation function
main() {
    print_section "Logitech G13 Linux Driver Installation"
    
    # Check if running in correct directory
    if [ ! -d "g13-driver" ] || [ ! -d "g13-config-tool" ]; then
        print_error "This script must be run from the linux-g13-driver directory"
        print_error "Expected structure:"
        echo "  linux-g13-driver/"
        echo "  ├── g13-driver/"
        echo "  ├── g13-config-tool/"
        echo "  └── install.sh"
        exit 1
    fi
    
    print_step "Detecting Linux distribution..."
    detect_distro
    print_success "Detected: $PRETTY_NAME"
    
    install_dependencies
    build_driver
    build_gui
    setup_config_dir
    setup_udev
    create_desktop_entry
    setup_systemd
    check_tray_icon
    
    print_section "Installation Complete!"
    echo ""
    echo -e "${GREEN}The G13 driver has been successfully installed.${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Check if driver is running: systemctl --user status g13-driver"
    echo "  2. If not running, reboot your system to apply all changes"
    echo "  3. Launch GUI from application menu: 'G13 Configuration'"
    echo "     Or run: java -jar g13-driver/Linux-G13-GUI.jar"
    echo ""
    echo "The driver will start automatically on login."
    echo ""
    
    # Check if service is currently running
    if systemctl --user is-active --quiet g13-driver.service; then
        print_success "Driver is currently running - you can test it now!"
        echo "  Look for the G13 tray icon in your system tray"
    else
        print_warning "Driver is not running yet. Reboot is recommended."
    fi
}

# Run main function
main
