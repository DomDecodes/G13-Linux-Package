package com.booker.g13;

import java.awt.BorderLayout;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * The main class for the G13 Configuration application.
 * FULLY INSTRUMENTED VERSION - Debug output everywhere!
 */
public class G13 extends JPanel {

	private static final long serialVersionUID = 1L;
	
	public static final String VERSION = G13.class.getPackage().getImplementationVersion() != null 
			? G13.class.getPackage().getImplementationVersion() 
			: "Development";
	
	private static final int MAX_MACROS = 200;

	// Named constants for the G13 keycodes of the M1, M2, M3, and MR buttons.
    private static final int BINDING_KEY_M1 = 25;
    private static final int BINDING_KEY_M2 = 26;
    private static final int BINDING_KEY_M3 = 27;
    private static final int BINDING_KEY_MR = 28;
    
    private static final Set<Integer> BINDING_SWITCH_KEYS = Set.of(
            BINDING_KEY_M1, BINDING_KEY_M2, BINDING_KEY_M3, BINDING_KEY_MR
    );
	
	// UI Components
	private final ImageMap g13Label = new ImageMap();
	private final KeybindPanel keybindPanel = new KeybindPanel();
	private final MacroEditorPanel macroEditorPanel = new MacroEditorPanel();
	
	// Data storage
	private final Properties[] keyBindings = new Properties[4];
	private final Properties[] macros = new Properties[MAX_MACROS];
	
	public G13() {
		System.out.println("═══════════════════════════════════════════════════════");
		System.out.println("DEBUG G13: Constructor starting");
		System.out.println("═══════════════════════════════════════════════════════");
		
		setLayout(new BorderLayout());
		
		loadConfiguration();
		
		keybindPanel.setBindings(0, keyBindings[0]);
		macroEditorPanel.setBindings(0, keyBindings[0]);
		
		// INSTRUMENTED: ImageMap listener
		g13Label.addListener(new ImageMapListener() {
			@Override
			public void selected(Key key) {
				System.out.println("╔═══════════════════════════════════════════════════════");
				System.out.println("║ DEBUG G13.ImageMapListener.selected() FIRED!");
				System.out.println("║ Key: " + (key != null ? "G" + key.getG13KeyCode() + " (" + key.toString() + ")" : "NULL"));
				System.out.println("╚═══════════════════════════════════════════════════════");
				
				if (key == null) {
					System.out.println("DEBUG G13: Deselecting key (null passed)");
					keybindPanel.setSelectedKey(null);
					return;
				}
				
				// Check if the selected key is one of the binding switch keys (M1-M3, MR).
				if (BINDING_SWITCH_KEYS.contains(key.getG13KeyCode())) {
					int profileNum = key.getG13KeyCode() - BINDING_KEY_M1;
					System.out.println("DEBUG G13: Profile switch key detected! Switching to profile " + profileNum);
					mapBindings(profileNum);
				} else {
					System.out.println("DEBUG G13: Regular key selected, passing to KeybindPanel");
					keybindPanel.setSelectedKey(key);
				}
			}

			@Override
			public void mouseover(Key key) {
				// Silent unless we need it
			}			
		});
		
		// --- UI Assembly ---
		final JPanel p = new JPanel(new BorderLayout());
		p.setBorder(BorderFactory.createTitledBorder("G13 Keypad"));
		p.add(g13Label, BorderLayout.CENTER);
		add(p, BorderLayout.CENTER);
		
		final JPanel rightPanel = new JPanel(new BorderLayout());
		rightPanel.add(keybindPanel, BorderLayout.NORTH);
		rightPanel.add(macroEditorPanel, BorderLayout.CENTER);
		add(rightPanel, BorderLayout.EAST);
		
		keybindPanel.setMacros(macros);
		macroEditorPanel.setMacros(macros);
		macroEditorPanel.setKeybindPanel(keybindPanel);
		
		System.out.println("DEBUG G13: Constructor complete, UI assembled");
	}

	private void loadConfiguration() {
		System.out.println("DEBUG G13: Loading configuration...");
		try {
			for (int i = 0; i < keyBindings.length; i++) {
				keyBindings[i] = Configs.loadBindings(i);
				System.out.println("DEBUG G13: Loaded binding profile " + i + " with " + keyBindings[i].size() + " entries");
			}
			
			for (int i = 0; i < macros.length; i++) {
				macros[i] = Configs.loadMacro(i);
			}
			System.out.println("DEBUG G13: Loaded " + macros.length + " macro definitions");
			
			mapBindings(0);
			System.out.println("DEBUG G13: Applied default profile 0 (M1)");
		}
		catch (IOException e) {
			System.err.println("ERROR G13: Failed to load configuration!");
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to load configuration:\n" + e.getMessage(), "Configuration Error", JOptionPane.ERROR_MESSAGE);
		}
	}
		
	private void mapBindings(int bindingNum) {
		System.out.println("──────────────────────────────────────────────────────");
		System.out.println("DEBUG G13.mapBindings(" + bindingNum + ") called");
		System.out.println("──────────────────────────────────────────────────────");
		
		keybindPanel.setSelectedKey(null);
		keybindPanel.setBindings(bindingNum, keyBindings[bindingNum]);
		macroEditorPanel.setBindings(bindingNum, keyBindings[bindingNum]);
		
		// Update visual representation
		for (int i = 0; i < 40; i++) { 
			final Key k = Key.getKeyFor(i);
			if (k == null) continue;

			String property = "G" + i;
			String val = keyBindings[bindingNum].getProperty(property);
			
			k.setMappedValue("Unassigned");
			k.setRepeats("N/A");
			
			if (val != null && !val.isBlank()) {
				String[] parts = val.split("[,.]");
				if (parts.length < 2) continue;

				final String type = parts[0];
				
				try {
					if ("p".equals(type)) {
						if (parts.length >= 3) {
							int keycode = Integer.parseInt(parts[2]);
							k.setMappedValue(JavaToLinuxKeymapping.cKeyCodeToString(keycode));
						}
					} else if ("m".equals(type)) {
						if (parts.length >= 3) {
							int macroNum = Integer.parseInt(parts[1]);
							if (macroNum >= 0 && macroNum < macros.length) {
								final String macroName = macros[macroNum].getProperty("name", "Unnamed Macro");
								boolean repeats = Integer.parseInt(parts[2]) != 0;
								k.setMappedValue("Macro: " + macroName);
								k.setRepeats(repeats ? "Yes" : "No");
							}
						}
					}
				} catch (NumberFormatException e) {
					System.err.println("Could not parse binding: " + val);
					k.setMappedValue("Parse Error");
				}
			}
		}
		System.out.println("DEBUG G13: Profile " + bindingNum + " mapping complete");
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }

            final JFrame frame = new JFrame("G13 Configuration Tool, Version " + VERSION);
            frame.setIconImage(ImageMap.G13_KEYPAD.getImage());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            final G13 g13 = new G13();	
            frame.getContentPane().add(g13, BorderLayout.CENTER);
            
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
            System.out.println("DEBUG G13.main: Application window is now visible");
        });
	}
}
