package com.booker.g13;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Properties;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * FULLY INSTRUMENTED VERSION - Debug output everywhere!
 */
public class MacroEditorPanel extends JPanel {

	private KeybindPanel keybindPanel = null;
	private int bindingsId = -1;
	private Properties bindings = null;

	public void setKeybindPanel(KeybindPanel panel) {
		System.out.println("DEBUG MacroEditorPanel: KeybindPanel reference set");
		this.keybindPanel = panel;
	}

	public void setBindings(int profileId, Properties bindings) {
		System.out.println("DEBUG MacroEditorPanel.setBindings(" + profileId + ") called");
		System.out.println("    Properties object: " + (bindings != null ? bindings.hashCode() : "NULL"));
		this.bindingsId = profileId;
		this.bindings = bindings;
	}

	private static final long serialVersionUID = 1L;

	private static final ImageIcon UP_ICON = ImageIconHelper.loadEmbeddedImage("/com/booker/g13/images/up.png", 16, 16);
	private static final ImageIcon DOWN_ICON = ImageIconHelper.loadEmbeddedImage("/com/booker/g13/images/down.png", 16, 16);
	private static final ImageIcon DELAY_ICON = ImageIconHelper.loadEmbeddedImage("/com/booker/g13/images/pause.png", 16, 16);

	private final JComboBox<Properties> macroSelectionBox = new JComboBox<>();
	private final DefaultListModel<String> listModel = new DefaultListModel<>();
	private final JList<String> macroList = new JList<>(listModel);
	private final JTextField nameText = new JTextField();
	private final JButton addDelayButton = new JButton("Add Delay");
	private final JCheckBox captureDelays = new JCheckBox("Rec Delays", true);
	private final JButton editButton = new JButton("Edit Delay");
	private final JButton deleteButton = new JButton("Delete Step");
	private final JButton recordButton = new JButton("Clear & Record");
	
	private volatile boolean loadingData = false;
	private volatile boolean captureMode = false;
	private long lastCapture = 0;

	public MacroEditorPanel(){
		System.out.println("DEBUG MacroEditorPanel: Constructor starting");
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createTitledBorder("Macro Editor Panel"));
		
		setupUI();
        attachListeners();
        setComponentStates(false);
		System.out.println("DEBUG MacroEditorPanel: Constructor complete");
	}
    
    private void setupUI() {
        final JPanel northPanel = new JPanel(new BorderLayout());
		northPanel.add(macroSelectionBox, BorderLayout.NORTH);

		final JPanel namePanel = new JPanel(new BorderLayout());
		namePanel.add(new JLabel("Name : "), BorderLayout.WEST);
		namePanel.add(nameText, BorderLayout.CENTER);
		northPanel.add(namePanel, BorderLayout.SOUTH);

		add(northPanel, BorderLayout.NORTH);
		add(new JScrollPane(macroList), BorderLayout.CENTER);

		final JPanel controls = new JPanel(new GridLayout(0, 1));
		final JPanel tmp1 = new JPanel(new GridLayout(1, 2));
		tmp1.add(captureDelays);
		tmp1.add(addDelayButton);
		controls.add(tmp1);

		final JPanel tmp2 = new JPanel(new GridLayout(1, 2));
		tmp2.add(editButton);
		tmp2.add(deleteButton);
		controls.add(tmp2);

		recordButton.setFocusTraversalKeysEnabled(false);

		final JPanel tmp3 = new JPanel(new GridLayout(1, 2));
		tmp3.add(recordButton);

		JButton saveProfileButton = new JButton("Save Current Profile");
		saveProfileButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Save Current Profile button clicked!");
			saveCurrentProfile();
		});
		tmp3.add(saveProfileButton);

		controls.add(tmp3);
		add(controls, BorderLayout.SOUTH);
    }

    private void attachListeners() {
		System.out.println("DEBUG MacroEditorPanel: Attaching listeners...");
		
        editButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Edit Delay button clicked!");
			edit();
		});
		
        deleteButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Delete Step button clicked!");
			delete();
		});
		
        addDelayButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Add Delay button clicked!");
			addDelay();
		});
		
        recordButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Record button clicked!");
			startStopRecording();
		});

        macroSelectionBox.addActionListener(e -> {
			System.out.println(">>> EVENT: Macro dropdown changed! Index=" + macroSelectionBox.getSelectedIndex());
			selectMacro();
		});
		
        macroList.setCellRenderer(new MacroStepCellRenderer());

        macroList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() > 1) {
					System.out.println(">>> EVENT: Macro list item double-clicked!");
                    edit();
                }
            }
        });
        
        macroList.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            updateButtonStates();
        });
        
        nameText.getDocument().addDocumentListener(new DocumentListener() {
			@Override public void changedUpdate(DocumentEvent e) { updateNameColor(); }
			@Override public void insertUpdate(DocumentEvent e) { updateNameColor(); }
			@Override public void removeUpdate(DocumentEvent e) { updateNameColor(); }
			private void updateNameColor() {
				nameText.setForeground(loadingData ? Color.black : Color.red);
			}
		});

        nameText.addActionListener(e -> {
			System.out.println(">>> EVENT: Name field Enter key pressed!");
			nameText.setForeground(Color.black);
			saveMacro();
			macroSelectionBox.repaint();
		});

        KeyListener keyListener = new KeyListener() {
			@Override
			public void keyPressed(KeyEvent event) {
				if (!captureMode) return;
				if (lastCapture != 0 && captureDelays.isSelected()) {
					listModel.addElement("d." + (event.getWhen() - lastCapture));
				}
				lastCapture = event.getWhen();
				listModel.addElement("kd." + JavaToLinuxKeymapping.keyEventToCCode(event));
			}

			@Override
			public void keyReleased(KeyEvent event) {
				if (!captureMode) return;
				if (lastCapture != 0 && captureDelays.isSelected()) {
					listModel.addElement("d." + (event.getWhen() - lastCapture));
				}
				lastCapture = event.getWhen();
				listModel.addElement("ku." + JavaToLinuxKeymapping.keyEventToCCode(event));
			}
			@Override public void keyTyped(KeyEvent e) { }
        };

		final JComponent[] componentsToListen = { this, macroSelectionBox, macroList, nameText, addDelayButton, captureDelays, recordButton, editButton, deleteButton };
		for (final JComponent c : componentsToListen) {
			c.addKeyListener(keyListener);
		}
		
		System.out.println("DEBUG MacroEditorPanel: All listeners attached");
    }

    private void updateButtonStates() {
        boolean canModify = canModifyMacro();
        int[] selectedIndices = macroList.getSelectedIndices();
        boolean selectionExists = selectedIndices.length > 0;

        deleteButton.setEnabled(selectionExists && canModify);
        
        boolean singleSelection = selectedIndices.length == 1;
        boolean isDelay = singleSelection && listModel.getElementAt(selectedIndices[0]).startsWith("d.");
        editButton.setEnabled(singleSelection && isDelay && canModify);
    }
    
    private void setComponentStates(boolean enabled) {
        final JComponent[] components = { macroSelectionBox, macroList, nameText, addDelayButton, captureDelays, editButton, deleteButton };
        for (JComponent c : components) {
            c.setEnabled(enabled);
        }
        recordButton.setEnabled(canModifyMacro());
    }

	private boolean canModifyMacro() {
		int selectedIndex = macroSelectionBox.getSelectedIndex(); 
		int defaultCount = Configs.DEFAULT_MACROS_COUNT;
		boolean result = selectedIndex >= defaultCount;

		System.out.println("DEBUG canModifyMacro: selectedIndex=" + selectedIndex + 
				", DEFAULT_MACROS_COUNT=" + defaultCount + 
				", result=" + result);

		return result;
	}

	public void startStopRecording() {
		System.out.println("DEBUG MacroEditorPanel.startStopRecording() called");
		captureMode = !captureMode;
        setComponentStates(!captureMode && canModifyMacro());
		
		if (captureMode) {
			recordButton.setText("Stop Recording");
			listModel.removeAllElements();
			lastCapture = 0;
            nameText.setEnabled(false);
			System.out.println("DEBUG MacroEditorPanel: Recording started");
		} else {
			recordButton.setText("Clear & Record");
            nameText.setEnabled(canModifyMacro());
			saveMacro();
			System.out.println("DEBUG MacroEditorPanel: Recording stopped, macro saved");
		}
	}

	public void delete() {
		System.out.println("DEBUG MacroEditorPanel.delete() called");
        if (!canModifyMacro()) {
			System.out.println("    Cannot modify this macro (read-only)");
			return;
		}
        int[] indices = macroList.getSelectedIndices();
        if (indices == null || indices.length == 0) {
			System.out.println("    No items selected");
			return;
		}

        for (int i = indices.length - 1; i >= 0; i--) {
            listModel.removeElementAt(indices[i]);
        }
		System.out.println("    Deleted " + indices.length + " step(s)");
        saveMacro();
    }
	
	public void edit() {
		System.out.println("DEBUG MacroEditorPanel.edit() called");
		if (!canModifyMacro()) {
			System.out.println("    Cannot modify this macro (read-only)");
			return;
		}
		int selectedIndex = macroList.getSelectedIndex();
		if (selectedIndex == -1) {
			System.out.println("    No item selected");
			return;
		}

		final String str = listModel.getElementAt(selectedIndex);
		if (!str.startsWith("d.")) {
			System.out.println("    Selected item is not a delay step");
			return;
		}

		try {
            int currentDelay = Integer.parseInt(str.substring(2));
            String newDelayStr = JOptionPane.showInputDialog(this, "Enter the delay in milliseconds", currentDelay);
            if (newDelayStr == null) return;

            int newDelay = Integer.parseInt(newDelayStr);
            listModel.set(selectedIndex, "d." + newDelay);
			System.out.println("    Delay changed from " + currentDelay + "ms to " + newDelay + "ms");
            saveMacro();
        } catch (NumberFormatException e) {
			System.err.println("    Invalid delay value entered");
            JOptionPane.showMessageDialog(this, "Invalid delay value: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
	}
	
	public void addDelay() {
		System.out.println("DEBUG MacroEditorPanel.addDelay() called");
        if (!canModifyMacro()) {
			System.out.println("    Cannot modify this macro (read-only)");
			return;
		}
        int pos = macroList.getSelectedIndex();
        if (pos == -1) {
            pos = listModel.getSize();
        } else {
            pos++;
        }

        try {
            String newDelayStr = JOptionPane.showInputDialog(this, "Enter the delay in milliseconds", 100);
            if (newDelayStr == null) return;
            
            int newDelay = Integer.parseInt(newDelayStr);
            listModel.insertElementAt("d." + newDelay, pos);
			System.out.println("    Added " + newDelay + "ms delay at position " + pos);
            saveMacro();
        } catch (NumberFormatException e) {
			System.err.println("    Invalid delay value entered");
            JOptionPane.showMessageDialog(this, "Invalid delay value: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
	}
	
	public void setMacros(final Properties[] macros) {
		System.out.println("DEBUG MacroEditorPanel.setMacros() called with " + macros.length + " macros");
        loadingData = true;
		macroSelectionBox.removeAllItems();
		
		for (final Properties properties : macros) {
			System.out.println("DEBUG: Adding macro id=" + properties.getProperty("id") + ", name=" + properties.getProperty("name"));
			macroSelectionBox.addItem(properties);
		}
		
        if (macroSelectionBox.getItemCount() > 0) {
		    macroSelectionBox.setSelectedIndex(0);
        }
        loadingData = false;
        selectMacro();
	}
	
	private void selectMacro() {
		System.out.println("╔══════════════════════════════════════════════════════════════");
		System.out.println("║ DEBUG MacroEditorPanel.selectMacro() called");
		System.out.println("║   loadingData: " + loadingData);
		System.out.println("║   selectedItem: " + macroSelectionBox.getSelectedItem());
		System.out.println("║   selectedIndex: " + macroSelectionBox.getSelectedIndex());
		
		if (macroSelectionBox.getSelectedItem() == null) {
			System.out.println("║   EARLY EXIT: No item selected");
			System.out.println("╚══════════════════════════════════════════════════════════════");
			return;
		}
		
        loadingData = true;

        boolean canModify = canModifyMacro();
		macroSelectionBox.setEnabled(true);
        captureDelays.setEnabled(canModify);
        addDelayButton.setEnabled(canModify);
        nameText.setEditable(canModify);
        recordButton.setEnabled(canModify);
        updateButtonStates();

		listModel.clear();
		
		final Properties macro = (Properties)macroSelectionBox.getSelectedItem();
		nameText.setText(macro.getProperty("name", ""));
		
		final String sequence = macro.getProperty("sequence", "");
		if (!sequence.isEmpty()) {
			for (String token : sequence.split(",")) {
                listModel.addElement(token);
            }
        }
		
		loadingData = false;
        nameText.setForeground(Color.black);
		
		// Notify KeybindPanel
        if (keybindPanel != null) {
            int selectedIndex = macroSelectionBox.getSelectedIndex();
            if (selectedIndex >= 0) {
				System.out.println("║   Notifying KeybindPanel to sync dropdown to index " + selectedIndex);
                keybindPanel.setSelectedMacro(selectedIndex);
            }
		}
		
		System.out.println("║   Macro selection complete");
		System.out.println("╚══════════════════════════════════════════════════════════════");
	}
	
	private void saveMacro() {
		System.out.println("┌──────────────────────────────────────────────────────────────");
		System.out.println("│ DEBUG MacroEditorPanel.saveMacro() ENTRY");
		System.out.println("│   loadingData: " + loadingData);
		System.out.println("│   canModify: " + canModifyMacro());
		
        if (loadingData || !canModifyMacro()) {
			String reason = loadingData ? "LOADING DATA" : "READ-ONLY MACRO";
			System.out.println("│ ⚠ EARLY EXIT: " + reason);
			System.out.println("└──────────────────────────────────────────────────────────────");
			return;
		}
		
		final int id = macroSelectionBox.getSelectedIndex();
		if (id == -1) {
			System.out.println("│ ⚠ EARLY EXIT: No macro selected");
			System.out.println("└──────────────────────────────────────────────────────────────");
			return;
		}

		final Properties macro = (Properties)macroSelectionBox.getSelectedItem();
		macro.setProperty("name", nameText.getText());
		
		final StringBuilder buf = new StringBuilder();
		for (int i = 0; i < listModel.getSize(); i++) {
			if (i > 0) {
				buf.append(",");
			}
			buf.append(listModel.getElementAt(i));
		}
		macro.setProperty("sequence", buf.toString());
		
		System.out.println("│   Saving macro " + id + ": name='" + nameText.getText() + "', steps=" + listModel.getSize());
		
		try {
			Configs.saveMacro(id, macro);
			System.out.println("│ ✓ Macro saved successfully to macro-" + id + ".properties");
		} catch (Exception e) {
			System.err.println("│ ✗ SAVE FAILED!");
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Could not save macro: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
		
		System.out.println("└──────────────────────────────────────────────────────────────");
	}
    
    private static class MacroStepCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            if (value instanceof String val) {
                String[] parts = val.split("\\.");
                if (parts.length == 2) {
                    String type = parts[0];
                    try {
                        int code = Integer.parseInt(parts[1]);
                        switch (type) {
                            case "d":
                                setText(String.format("%.3f seconds", code / 1000.0));
                                setIcon(DELAY_ICON);
                                break;
                            case "kd":
                                setText(JavaToLinuxKeymapping.cKeyCodeToString(code));
                                setIcon(DOWN_ICON);
                                break;
                            case "ku":
                                setText(JavaToLinuxKeymapping.cKeyCodeToString(code));
                                setIcon(UP_ICON);
                                break;
                            default:
                                setIcon(null);
                        }
                    } catch (NumberFormatException e) {
                        setText(val);
                        setIcon(null);
                    }
                } else {
                    setText(val);
                    setIcon(null);
                }
            }
            return this;
        }
	}
	
    private void saveCurrentProfile() {
		System.out.println("╔══════════════════════════════════════════════════════════════");
		System.out.println("║ DEBUG MacroEditorPanel.saveCurrentProfile() called");
		System.out.println("║   bindingsId: " + bindingsId);
		System.out.println("║   bindings: " + (bindings != null ? "exists (hashCode=" + bindings.hashCode() + ")" : "NULL"));
		
        if (bindingsId < 0 || bindings == null) {
			System.out.println("║ ⚠ EARLY EXIT: No profile active");
			System.out.println("╚══════════════════════════════════════════════════════════════");
            JOptionPane.showMessageDialog(this, 
                "No profile selected. Please click M1, M2, M3, or MR first.", 
                "No Profile Active", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
		
		System.out.println("║   Properties contains " + bindings.size() + " entries");
		System.out.println("║   Sample entries:");
		bindings.forEach((key, value) -> {
			if (key.toString().startsWith("G")) {
				System.out.println("║     " + key + " = " + value);
			}
		});
        
        try {
            Configs.saveBindings(bindingsId, bindings);
            String profileName = new String[]{"M1", "M2", "M3", "MR"}[bindingsId];
			System.out.println("║ ✓ Successfully saved profile " + profileName + " to bindings-" + bindingsId + ".properties");
			System.out.println("╚══════════════════════════════════════════════════════════════");
            
            // First dialog: Save confirmation
            JOptionPane.showMessageDialog(this, 
                "Profile " + profileName + " saved successfully!", 
                "Save Complete", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Second dialog: Ask to restart driver
            int choice = JOptionPane.showConfirmDialog(this,
                "Profile saved successfully!\n\n" +
                "Restart the G13 driver to apply changes?",
                "Apply Changes to Driver?",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (choice == JOptionPane.YES_OPTION) {
                restartDriver();
            } else {
                System.out.println("DEBUG: User chose NOT to restart driver");
            }
            
        } catch (IOException ex) {
			System.err.println("║ ✗ SAVE FAILED!");
			System.out.println("╚══════════════════════════════════════════════════════════════");
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error saving profile: " + ex.getMessage(), 
                "Save Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Restarts the G13 driver service to apply configuration changes.
     */
    private void restartDriver() {
        System.out.println("╔══════════════════════════════════════════════════════════════");
        System.out.println("║ DEBUG MacroEditorPanel.restartDriver() called");
        System.out.println("╚══════════════════════════════════════════════════════════════");
        
        try {
            System.out.println("Executing: systemctl --user restart g13-driver.service");
            ProcessBuilder pb = new ProcessBuilder("systemctl", "--user", "restart", "g13-driver.service");
            pb.redirectErrorStream(true);
            Process p = pb.start();
            
            // Wait for the command to complete
            int exitCode = p.waitFor();
            
            if (exitCode == 0) {
                System.out.println("✓ Driver restarted successfully! Exit code: " + exitCode);
                JOptionPane.showMessageDialog(this,
                    "Driver restarted successfully!\n\n" +
                    "Your changes are now active.",
                    "Driver Restarted",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                System.err.println("✗ Driver restart failed! Exit code: " + exitCode);
                JOptionPane.showMessageDialog(this,
                    "Failed to restart driver (exit code: " + exitCode + ").\n\n" +
                    "You may need to restart it manually:\n" +
                    "systemctl --user restart g13-driver",
                    "Restart Failed",
                    JOptionPane.WARNING_MESSAGE);
            }
            
        } catch (InterruptedException e) {
            System.err.println("✗ Driver restart interrupted: " + e.getMessage());
            Thread.currentThread().interrupt();
            JOptionPane.showMessageDialog(this,
                "Driver restart was interrupted.\n\n" +
                "You can restart manually with:\n" +
                "systemctl --user restart g13-driver",
                "Restart Interrupted",
                JOptionPane.WARNING_MESSAGE);
        } catch (IOException e) {
            System.err.println("✗ Error executing restart command: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error restarting driver: " + e.getMessage() + "\n\n" +
                "You can restart manually with:\n" +
                "systemctl --user restart g13-driver",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}