#!/bin/bash
#
# Logitech G13 Linux Driver - Automated Installation Script
# This script installs and configures the G13 driver with GUI
#

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Pretty print functions
print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
}

print_step() {
    echo -e "${GREEN}▶ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    print_error "Do not run this script as root!"
    print_warning "Run as your normal user. The script will ask for sudo when needed."
    exit 1
fi

print_header "Logitech G13 Linux Driver Installation"

# Detect distribution
print_step "Detecting Linux distribution..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    print_success "Detected: $PRETTY_NAME"
else
    print_error "Cannot detect distribution"
    exit 1
fi

# Install dependencies
print_step "Installing dependencies..."

case $DISTRO in
    ubuntu|debian|pop)
        sudo apt update
        sudo apt install -y \
            build-essential \
            libusb-1.0-0-dev \
            openjdk-17-jdk \
            maven \
            libayatana-appindicator3-dev \
            git
        ;;
    fedora)
        sudo dnf install -y \
            gcc gcc-c++ make \
            libusb-devel \
            java-17-openjdk-devel \
            maven \
            libayatana-appindicator-gtk3-devel \
            git
        ;;
    arch|manjaro)
        sudo pacman -S --needed \
            base-devel \
            libusb \
            jdk-openjdk \
            maven \
            libayatana-appindicator \
            git
        ;;
    *)
        print_warning "Unsupported distribution: $DISTRO"
        print_warning "Please install dependencies manually:"
        echo "  - build-essential / base-devel"
        echo "  - libusb-1.0-dev"
        echo "  - openjdk-17-jdk (or newer)"
        echo "  - maven"
        echo "  - libayatana-appindicator3-dev"
        echo "  - git"
        read -p "Press Enter when dependencies are installed..."
        ;;
esac

print_success "Dependencies installed"

# Set installation directory
INSTALL_DIR="$HOME/src/linux-g13-driver"

# Check if already installed
if [ -d "$INSTALL_DIR" ]; then
    print_warning "Installation directory already exists: $INSTALL_DIR"
    read -p "Remove and reinstall? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$INSTALL_DIR"
    else
        print_error "Installation cancelled"
        exit 1
    fi
fi

# Create src directory if needed
mkdir -p "$HOME/src"

# Clone repository (or copy if running from extracted archive)
print_step "Setting up source code..."

if [ -f "$(dirname "$0")/g13-driver/src/Makefile" ]; then
    # Running from extracted archive
    print_step "Copying files from archive..."
    cp -r "$(dirname "$0")" "$INSTALL_DIR"
else
    # Clone from GitHub
    print_step "Cloning from GitHub..."
    # TODO: Replace with your actual GitHub URL
    git clone https://github.com/YOUR_USERNAME/linux-g13-driver.git "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"
print_success "Source code ready"

# Build C++ driver
print_step "Building C++ driver..."
cd g13-driver/src
make clean
make
print_success "Driver compiled"

# Build Java GUI
print_step "Building Java GUI..."
cd ../../g13-config-tool
mvn clean package
print_success "GUI compiled"

# Copy JAR to driver directory
print_step "Installing GUI..."
cp target/Linux-G13-GUI.jar ../g13-driver/
print_success "GUI installed"

# Install udev rules
print_step "Installing udev rules..."
cd ../g13-driver/src
sudo cp udev/99-g13-plugdev.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules
sudo udevadm trigger
print_success "udev rules installed"

# Add user to plugdev group
print_step "Adding user to plugdev group..."
sudo usermod -a -G plugdev $USER
print_success "User added to plugdev group"

# Create systemd service
print_step "Creating systemd service..."
mkdir -p ~/.config/systemd/user

cat > ~/.config/systemd/user/g13-driver.service << EOF
[Unit]
Description=Logitech G13 Driver
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR/g13-driver
ExecStart=$INSTALL_DIR/g13-driver/Linux-G13-Driver
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable g13-driver.service
print_success "Systemd service created and enabled"

# Create desktop launcher
print_step "Creating desktop launcher..."
mkdir -p ~/.local/share/applications

cat > ~/.local/share/applications/g13-config.desktop << EOF
[Desktop Entry]
Name=G13 Configuration
Comment=Configure Logitech G13 Gameboard
Exec=java -jar $INSTALL_DIR/g13-driver/Linux-G13-GUI.jar
Icon=input-gaming
Terminal=false
Type=Application
Categories=Settings;HardwareSettings;
EOF

print_success "Desktop launcher created"

# Create launcher script
print_step "Creating convenience launcher..."
cat > "$INSTALL_DIR/launch-gui.sh" << EOF
#!/bin/bash
cd "$INSTALL_DIR/g13-driver"
java -jar Linux-G13-GUI.jar
EOF
chmod +x "$INSTALL_DIR/launch-gui.sh"
print_success "Launcher script created"

# Final instructions
print_header "Installation Complete!"

echo ""
print_warning "CRITICAL: You must REBOOT your system for everything to work properly!"
echo ""
print_warning "Why reboot is required:"
echo "  - Group permissions (plugdev) need to take effect"
echo "  - System tray icon needs proper initialization"
echo "  - Driver auto-start needs to be configured"
echo ""

print_step "After rebooting:"
echo "  1. Plug in your G13 (if not already connected)"
echo "  2. Look for the G13 tray icon in your system tray"
echo "  3. Launch 'G13 Configuration' from your application menu"
echo "  4. Select a G-key, assign a macro or passthrough key"
echo "  5. Click 'Save Current Profile' and choose 'Yes' to restart driver"
echo ""

print_step "To check driver status after reboot:"
echo "  systemctl --user status g13-driver"
echo ""

print_step "To view driver logs:"
echo "  journalctl --user -u g13-driver -f"
echo ""

print_success "Installation script completed successfully!"
echo ""
print_warning "═══════════════════════════════════════════════════════════════"
print_warning "  REBOOT NOW: sudo reboot"
print_warning "═══════════════════════════════════════════════════════════════"
