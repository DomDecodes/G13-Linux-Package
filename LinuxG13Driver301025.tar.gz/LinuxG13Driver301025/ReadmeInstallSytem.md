# G13 Driver - Proper System Installation

## 🎯 The Problem You Had

The old install script kept the driver in your Downloads folder:
```
~/Downloads/LinuxG13Driver291025/g13-driver/Linux-G13-Driver
```

When you emptied Downloads → Driver disappeared → Service couldn't find it → Stopped working! ❌

---

## ✅ The Solution: System-Wide Installation

This new script **installs to permanent system locations**:

```
Driver:    /usr/local/bin/g13-driver
GUI:       /opt/g13/Linux-G13-GUI.jar
Config:    ~/.g13/
Service:   ~/.config/systemd/user/g13-driver.service
```

**After installation, you can DELETE the source folder!** Everything is safely installed to permanent locations. ✅

---

## 📦 What Gets Installed Where

### System Binaries:
```
/usr/local/bin/g13-driver           # The driver (permanent location)
```

### Application Data:
```
/opt/g13/Linux-G13-GUI.jar          # Configuration GUI
```

### User Config:
```
~/.g13/                              # Your settings
├── bindings-0.properties            # M1 profile
├── bindings-1.properties            # M2 profile
├── bindings-2.properties            # M3 profile
├── bindings-3.properties            # MR profile
└── macro-*.properties               # Macros
```

### System Service:
```
~/.config/systemd/user/g13-driver.service   # Points to /usr/local/bin/g13-driver
```

### Menu Entries:
```
~/.local/share/applications/
├── g13-start-driver.desktop         # "G13 Start Driver"
└── g13-config.desktop               # "G13 Configuration"
```

### System Permissions:
```
/etc/udev/rules.d/99-g13-plugdev.rules   # USB access
```

---

## 🚀 Installation

```bash
cd ~/Downloads/LinuxG13Driver291025
chmod +x install-system.sh
./install-system.sh
```

Then **reboot**.

After reboot:
1. Open menu → Search "G13 Start Driver"
2. Click it
3. Driver starts with tray icon

---

## 🗑️ Can I Delete the Source Folder Now?

**YES!** After running `install-system.sh`, everything is copied to permanent locations.

```bash
cd ~/Downloads
rm -rf LinuxG13Driver291025
```

The driver will continue to work because it's now installed at `/usr/local/bin/g13-driver`.

---

## 🔄 How This Compares to Ubuntu Studio

**Ubuntu Studio probably did this too!** The driver was installed to system locations, which is why it survived folder deletions.

| Approach | Driver Location | Can Delete Source? | Survives Cleanup? |
|----------|----------------|-------------------|------------------|
| **Old Script** | `~/Downloads/...` | ❌ No | ❌ No |
| **This Script** | `/usr/local/bin/` | ✅ Yes | ✅ Yes |
| **Ubuntu Studio** | `/usr/local/bin/` | ✅ Yes | ✅ Yes |

---

## 📋 Both Menu Entries Included

This script creates **both** menu entries automatically:

### 1. G13 Start Driver
- Starts the driver service
- Shows popup when started
- Checks if G13 is plugged in

### 2. G13 Configuration  
- Opens the GUI to configure keys/macros
- Points to permanent location: `/opt/g13/Linux-G13-GUI.jar`

No need to run separate scripts - everything is in one installation!

---

## 🔧 Uninstall (if needed)

```bash
# Stop and disable service
systemctl --user stop g13-driver
systemctl --user disable g13-driver
systemctl --user daemon-reload

# Remove installed files
sudo rm /usr/local/bin/g13-driver
sudo rm -rf /opt/g13
rm -rf ~/.g13
rm ~/.config/systemd/user/g13-driver.service
rm ~/.local/share/applications/g13-*.desktop
rm ~/.local/bin/start-g13-driver
sudo rm /etc/udev/rules.d/99-g13-plugdev.rules

# Reload udev
sudo udevadm control --reload-rules
```

---

## ⚙️ Technical Details

### Why /usr/local/bin?
- Standard location for user-installed binaries
- Already in system PATH
- Persists across system updates
- Doesn't require modifying system packages

### Why /opt/g13?
- Standard location for third-party applications
- Keeps GUI separate from system binaries
- Easy to find and manage

### Why ~/.g13?
- User-specific configuration
- Won't affect other users
- Easy to backup
- Standard XDG config pattern

---

## 🎯 Summary

**This is a proper, traditional Linux installation:**
- ✅ Installs to standard system locations
- ✅ Survives folder cleanups
- ✅ Creates both menu entries
- ✅ Works like professional software
- ✅ You can delete the source folder after install

Just like Ubuntu Studio did it! This is the "right way" to install software on Linux.
