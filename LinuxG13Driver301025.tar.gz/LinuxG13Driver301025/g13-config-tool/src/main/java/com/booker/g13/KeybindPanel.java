package com.booker.g13;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * FIXED VERSION - loadingData flag now correctly set before save attempt!
 */
public class KeybindPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private final JCheckBox passthroughButton = new JCheckBox("Pass Through");
	private final JTextField passthroughText = new JTextField();
	private int passthroughCode = 0;
	
	private final JCheckBox macroButton = new JCheckBox("Macro");
	private final JComboBox<Properties> macroSelectionBox = new JComboBox<>();
	private final JCheckBox repeatsCheckBox = new JCheckBox("Auto Repeat");
	
	private final JButton colorChangeButton = new JButton("Click Here To Change");
	
	private int bindingsId = -1;
	private Properties bindings;
	private Properties[] macros;
	private Key key = null;
	
	private volatile boolean loadingData = false;
	
	public KeybindPanel() {
		System.out.println("DEBUG KeybindPanel: Constructor starting");
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createTitledBorder("Keybindings Panel"));
		
		setupUI();
        attachListeners();
		
		setSelectedKey(null);
		System.out.println("DEBUG KeybindPanel: Constructor complete");
	}
	
	private void setupUI() {
		add(createColorPanel(), BorderLayout.NORTH);
		
		final ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(passthroughButton);
		buttonGroup.add(macroButton);
		
		passthroughText.setFocusTraversalKeysEnabled(false);
		
		final JPanel grid = new JPanel(new GridLayout(0, 2, 5, 5));
		grid.add(passthroughButton);
		grid.add(passthroughText);
		grid.add(new JLabel(" "));
		grid.add(new JLabel(" "));
		grid.add(macroButton);
		grid.add(macroSelectionBox);
		grid.add(new JLabel(" "));
		grid.add(repeatsCheckBox);
		
		grid.setBorder(BorderFactory.createTitledBorder("Button Type"));
		
		macroSelectionBox.setRenderer(new MacroListCellRenderer());
		
		add(grid, BorderLayout.CENTER);
	}

	private void attachListeners() {
		System.out.println("DEBUG KeybindPanel: Attaching listeners...");
		
		macroButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Macro checkbox clicked! Selected=" + macroButton.isSelected());
			updateComponentStateAndSave();
		});
		
		macroSelectionBox.addActionListener(e -> {
			System.out.println(">>> EVENT: Macro dropdown changed! Index=" + macroSelectionBox.getSelectedIndex());
			saveBindings();
		});
		
		repeatsCheckBox.addActionListener(e -> {
			System.out.println(">>> EVENT: Repeats checkbox clicked! Selected=" + repeatsCheckBox.isSelected());
			saveBindings();
		});
		
		passthroughButton.addActionListener(e -> {
			System.out.println(">>> EVENT: Passthrough checkbox clicked! Selected=" + passthroughButton.isSelected());
			updateComponentStateAndSave();
		});

		passthroughText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				System.out.println(">>> EVENT: Passthrough text key released! Code=" + event.getKeyCode());
				if (loadingData) {
					System.out.println("    (Ignored - loadingData=true)");
					return;
				}
				loadingData = true;
				passthroughCode = JavaToLinuxKeymapping.keyEventToCCode(event);
				passthroughText.setText(JavaToLinuxKeymapping.cKeyCodeToString(passthroughCode));
				loadingData = false;
				saveBindings();
			}
		});
		
		System.out.println("DEBUG KeybindPanel: All listeners attached");
	}

    private void updateComponentStateAndSave() {
        System.out.println("DEBUG KeybindPanel.updateComponentStateAndSave() called");
        System.out.println("    Passthrough selected: " + passthroughButton.isSelected());
        System.out.println("    Macro selected: " + macroButton.isSelected());
        
        passthroughText.setEnabled(passthroughButton.isSelected());
        macroSelectionBox.setEnabled(macroButton.isSelected());
        repeatsCheckBox.setEnabled(macroButton.isSelected());
        
        saveBindings();
    }
	
	public void setMacros(final Properties[] macros) {
		System.out.println("DEBUG KeybindPanel.setMacros() called with " + macros.length + " macros");
		loadingData = true;
		this.macros = macros;
		
		macroSelectionBox.removeAllItems();
		for (final Properties properties : macros) {
			macroSelectionBox.addItem(properties);
		}
		
		loadingData = false;
		System.out.println("DEBUG KeybindPanel: Macros loaded into dropdown");
	}
	
	public void setSelectedMacro(int macroIndex) {
		System.out.println("╔══════════════════════════════════════════════════════════════");
		System.out.println("║ DEBUG KeybindPanel.setSelectedMacro(" + macroIndex + ") called");
		System.out.println("║   This is a USER ACTION from MacroEditorPanel");
		System.out.println("║   We WILL sync the dropdown AND save the binding!");
		System.out.println("╚══════════════════════════════════════════════════════════════");
		
		if (macroIndex >= 0 && macroIndex < macroSelectionBox.getItemCount()) {
			// Temporarily block the dropdown's ActionListener to prevent double-save
			loadingData = true;
			macroSelectionBox.setSelectedIndex(macroIndex);
			loadingData = false;
			
			// 🔧 THE FIX: Now actually save the new macro binding!
			// The user selected a macro in MacroEditorPanel, so save it to the key!
			System.out.println("DEBUG KeybindPanel: Dropdown synced to index " + macroIndex);
			saveBindings();
			System.out.println("DEBUG KeybindPanel: Binding saved!");
		} else {
			System.out.println("DEBUG KeybindPanel: Invalid macro index " + macroIndex);
		}
	}

	public void setBindings(final int propertyNum, final Properties bindings) {
		System.out.println("──────────────────────────────────────────────────────");
		System.out.println("DEBUG KeybindPanel.setBindings(" + propertyNum + ") called");
		System.out.println("    Properties object: " + (bindings != null ? bindings.hashCode() : "NULL"));
		System.out.println("──────────────────────────────────────────────────────");
		
		loadingData = true;
		
		this.bindingsId = propertyNum;
		this.bindings = bindings;
		
		final String val = bindings.getProperty("color", "255,255,255");
		try {
			String[] parts = val.split(",");
			if (parts.length == 3) {
				int r = Integer.parseInt(parts[0].trim());
				int g = Integer.parseInt(parts[1].trim());
				int b = Integer.parseInt(parts[2].trim());
				colorChangeButton.setBackground(new Color(r, g, b));
				System.out.println("DEBUG KeybindPanel: Color set to RGB(" + r + "," + g + "," + b + ")");
			}
		} catch (NumberFormatException e) {
			System.err.println("Invalid color format in properties: " + val);
			colorChangeButton.setBackground(Color.WHITE);
		}
		
		setSelectedKey(null);
		loadingData = false;
		System.out.println("DEBUG KeybindPanel: Profile " + propertyNum + " loaded");
	}
	
	public void setSelectedKey(final Key key) {
		System.out.println("╔══════════════════════════════════════════════════════════════");
		System.out.println("║ DEBUG KeybindPanel.setSelectedKey() called");
		System.out.println("║   Key: " + (key != null ? "G" + key.getG13KeyCode() : "NULL (deselect)"));
		System.out.println("╚══════════════════════════════════════════════════════════════");
		
		this.key = key;
		loadingData = true;
		
		final boolean isKeySelected = (key != null);
		final JComponent[] all = { colorChangeButton, macroButton, macroSelectionBox, passthroughButton, passthroughText, repeatsCheckBox };
		for (final JComponent c : all) {
			c.setEnabled(isKeySelected);
		}
		
		if (!isKeySelected) {
			System.out.println("DEBUG KeybindPanel: No key selected, panel disabled");
			loadingData = false;
			return;
		}
		
		final String propKey = "G" + key.getG13KeyCode();
		final String val = bindings.getProperty(propKey, "p,k.1");
		System.out.println("DEBUG KeybindPanel: Loading binding for " + propKey + " = " + val);
		
		String[] parts = val.split("[,.]");
		String type = parts.length > 0 ? parts[0] : "p";
		
		try {
			if ("p".equals(type)) {
				passthroughButton.setSelected(true);
				passthroughCode = (parts.length >= 3) ? Integer.parseInt(parts[2]) : 1;
				passthroughText.setText(JavaToLinuxKeymapping.cKeyCodeToString(passthroughCode));
				System.out.println("DEBUG KeybindPanel: Loaded PASSTHROUGH binding, code=" + passthroughCode);
			} else {
				macroButton.setSelected(true);
				int macroNum = (parts.length >= 2) ? Integer.parseInt(parts[1]) : 0;
				macroSelectionBox.setSelectedIndex(macroNum);  // ← This triggers ActionListener!
				boolean repeats = (parts.length >= 3) && (Integer.parseInt(parts[2]) != 0);
				repeatsCheckBox.setSelected(repeats);
				System.out.println("DEBUG KeybindPanel: Loaded MACRO binding, macro=" + macroNum + ", repeats=" + repeats);
			}
		} catch(NumberFormatException | ArrayIndexOutOfBoundsException e) {
			System.err.println("Failed to parse binding property: " + val);
			passthroughButton.setSelected(true);
		}
		
		// ═══════════════════════════════════════════════════════════════
		// 🔧 THE FIX: Set loadingData to false AFTER loading UI but BEFORE save!
		// We must set it AFTER setSelectedIndex() but BEFORE the save call.
		// ═══════════════════════════════════════════════════════════════
		loadingData = false;
		
		// Now update component states and save
		passthroughText.setEnabled(passthroughButton.isSelected());
		macroSelectionBox.setEnabled(macroButton.isSelected());
		repeatsCheckBox.setEnabled(macroButton.isSelected());
		
		// Now do the actual save
		saveBindings();
		// ═══════════════════════════════════════════════════════════════
		
		System.out.println("DEBUG KeybindPanel: Key selection complete");
	}
	
	private void changeScreenColor() {
		System.out.println(">>> EVENT: Color button clicked!");
		
		final Color currentColor = colorChangeButton.getBackground();
		final Color newColor = JColorChooser.showDialog(this, "Choose Screen Color", currentColor);
		
		if (newColor == null) {
			System.out.println("DEBUG KeybindPanel: Color selection cancelled");
			return;
		}
		
		bindings.setProperty("color", newColor.getRed() + "," + newColor.getGreen() + "," + newColor.getBlue());
		colorChangeButton.setBackground(newColor);
		System.out.println("DEBUG KeybindPanel: Color changed to RGB(" + newColor.getRed() + "," + newColor.getGreen() + "," + newColor.getBlue() + ")");
		
		try {
			Configs.saveBindings(bindingsId, bindings);
			System.out.println("DEBUG KeybindPanel: Color saved successfully");
		} catch (IOException e) {
			System.err.println("ERROR KeybindPanel: Failed to save color!");
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Could not save color setting: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private JPanel createColorPanel() {
		final JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
		p.setBorder(BorderFactory.createTitledBorder("Screen Color"));
		p.add(colorChangeButton);
		colorChangeButton.addActionListener(e -> changeScreenColor());
		return p;
	}
	
	private void saveBindings() {
		System.out.println("┌──────────────────────────────────────────────────────────────");
		System.out.println("│ DEBUG KeybindPanel.saveBindings() ENTRY");
		System.out.println("│   key: " + (key != null ? "G" + key.getG13KeyCode() : "NULL"));
		System.out.println("│   loadingData: " + loadingData);
		System.out.println("│   bindingsId: " + bindingsId);
		
		if (key == null || loadingData) {
			String reason = key == null ? "NO KEY SELECTED" : "LOADING DATA";
			System.out.println("│ ⚠ EARLY EXIT: " + reason);
			System.out.println("└──────────────────────────────────────────────────────────────");
			return;
		}
		
		System.out.println("│ ✓ Proceeding with save...");
		
		String prop = "G" + key.getG13KeyCode();
		if (passthroughButton.isSelected()) {
			String val = "p,k." + passthroughCode;
			bindings.put(prop, val);
			key.setMappedValue(passthroughText.getText().trim());
			key.setRepeats("N/A");
			System.out.println("│   Saving PASSTHROUGH: " + prop + " = " + val);
		} else if (macroButton.isSelected()) {
			int macroNum = macroSelectionBox.getSelectedIndex();
			int repeats = repeatsCheckBox.isSelected() ? 1 : 0;
			String val = "m," + macroNum + "," + repeats;
			bindings.put(prop, val);
			
			if (macros != null && macroNum >= 0 && macroNum < macros.length) {
				final String macroName = macros[macroNum].getProperty("name", "Unnamed Macro");
				key.setMappedValue("Macro: " + macroName);
				key.setRepeats(repeats == 1 ? "Yes" : "No");
			}
			System.out.println("│   Saving MACRO: " + prop + " = " + val);
		} else {
			bindings.remove(prop);
			key.setMappedValue("Unassigned");
			key.setRepeats("N/A");
			System.out.println("│   Removing binding for " + prop);
		}
		
		try {
			Configs.saveBindings(bindingsId, bindings);
			System.out.println("│ ✓ Save successful! Written to bindings-" + bindingsId + ".properties");
		} catch (IOException e) {
			System.err.println("│ ✗ SAVE FAILED!");
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Can't Save Bindings: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
		
		System.out.println("└──────────────────────────────────────────────────────────────");
	}
}
