# Logitech G13 Linux Driver - Installation Package

**Version 2.0.0** - Fully Functional with GUI

---

## 📦 Quick Start - Two Ways to Install:


### Method 1: Automated Script (Terminal)

**For users comfortable with terminal:**

1. Open terminal in this folder (right click; open terminal here)
2. Run:  ./install.sh
3. Follow the prompts
4. Reboot when done

---

### Method 3: Manual Installation (Advanced)

**For users who want full control:**

1. Follow the steps in ReadmeG13Package.md and install
   everything separately.

---

## ⚠️ Important Notes

### Before Installation:
- ✅ Make sure you have **administrator (sudo) password**
- ✅ Ensure you have **internet connection** (for downloading dependencies)
- ✅ **Plug in your G13** before starting

### After Installation:
- ⚠️ **YOU MUST REBOOT** your system (not just log out!)
- ⚠️ Reboot is **required** for group permissions and tray icon to work
- ⚠️ Don't skip the reboot step!

### Desktop Environment Notes:
- **KDE Plasma:** Works out of the box ✓
- **GNOME:** Requires AppIndicator extension (installer will prompt you)
- **XFCE/MATE:** Works with minor configuration
- **Other DEs:** Should work if they support system tray

---

## 📁 What's in This Package?

```
linux-g13-driver/
├── Install-G13-Driver.desktop  ← Double-click this for GUI installer!
├── gui-installer.sh           ← Graphical installation wizard
├── install.sh                 ← Text-based automated installer
├── ReadmeG13Package.md        ← Full documentation (you are here)
├── changelog.md               ← What's new in this version
├── g13-driver/                ← C++ driver source code
├── g13-config-tool/           ← Java GUI source code
└── docs/                      ← Additional documentation
```

---

## 🎮 After Installation & Reboot

### Step 1: Launch the GUI
- Look for **"G13 Configuration"** in your application menu
- Or look for the **G13 tray icon** in your system tray

### Step 2: Configure Your First Key
1. Click a **G-key** on the image (e.g., G1)
2. Choose **"Passthrough"** and press a key (e.g., press 'A')
   - OR choose **"Macro"** and select a macro from dropdown
3. Click **"Save Current Profile"** button
4. Choose **"Yes"** when asked to restart driver
5. **Test it!** Press G1 on your physical G13

### Step 3: Create Your First Macro
1. Select macro slot **16 or higher** (0-15 are read-only defaults)
2. Give it a name (e.g., "Ctrl+A")
3. Click **"Clear & Record"**
4. Press your key sequence (e.g., Ctrl+A)
5. Click **"Stop Recording"**
6. Assign this macro to a G-key
7. Click **"Save Current Profile"** → **"Yes"**
8. **Test it!**

---

## 🔧 Troubleshooting

### No tray icon after installation?
→ **Did you reboot?** This is required!
→ On GNOME? Run: `sudo apt install gnome-shell-extension-appindicator`

### Driver not starting?
```bash
# Check driver status:
systemctl --user status g13-driver

# View logs:
journalctl --user -u g13-driver -f

# Manually start:
systemctl --user start g13-driver
```

### Permission denied errors?
→ **Did you reboot?** Group permissions need a reboot to take effect!

### Changes not applying?
→ Always click **"Save Current Profile"** after making changes
→ Choose **"Yes"** when prompted to restart driver

---

## 📚 Full Documentation

For complete documentation, see:
- **ReadmeG13Package.md** - Complete feature list and usage guide
- **changelog.md** - Technical details of what was fixed
- **docs/** folder - Additional guides and troubleshooting

---


## 💬 Questions?

- Check the **ReadmeG13Package.md** file
- Visit the GitHub repository
- Watch the YouTube tutorial

---

**Happy gaming with your G13 on Linux!** 🎮🐧
