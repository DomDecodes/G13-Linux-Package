#!/bin/bash

# Logitech G13 Linux Driver - Proper System Installation
# This installs the driver to permanent system locations

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

CHECK="${GREEN}✓${NC}"
ARROW="${BLUE}▶${NC}"
WARN="${YELLOW}⚠${NC}"
ERROR="${RED}✗${NC}"

print_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e " $1"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
}

print_step() {
    echo -e "${ARROW} $1"
}

print_success() {
    echo -e "${CHECK} $1"
}

print_warning() {
    echo -e "${WARN} $1"
}

print_error() {
    echo -e "${ERROR} $1"
}

# Detect Linux distribution
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
        VERSION=$VERSION_ID
        PRETTY_NAME=$PRETTY_NAME
    else
        print_error "Cannot detect Linux distribution"
        exit 1
    fi
}

# Install dependencies based on distribution
install_dependencies() {
    print_step "Installing dependencies..."
    
    case "$DISTRO" in
        ubuntu|debian|neon|pop|linuxmint|elementary)
            print_success "Detected Debian/Ubuntu-based system: $PRETTY_NAME"
            sudo apt update
            sudo apt install -y \
                build-essential \
                libusb-1.0-0-dev \
                openjdk-17-jdk \
                maven \
                libayatana-appindicator3-dev \
                git \
                pkg-config
            ;;
        
        arch|manjaro|endeavouros)
            print_success "Detected Arch-based system: $PRETTY_NAME"
            sudo pacman -Syu --needed --noconfirm \
                base-devel \
                libusb \
                jdk-openjdk \
                maven \
                libayatana-appindicator \
                git \
                pkg-config
            ;;
        
        fedora|rhel|centos|rocky|almalinux)
            print_success "Detected Red Hat-based system: $PRETTY_NAME"
            sudo dnf install -y \
                gcc-c++ \
                make \
                libusb1-devel \
                java-17-openjdk-devel \
                maven \
                libayatana-appindicator-gtk3-devel \
                git \
                pkgconfig
            ;;
        
        opensuse*|suse)
            print_success "Detected openSUSE: $PRETTY_NAME"
            sudo zypper install -y \
                gcc-c++ \
                make \
                libusb-1_0-devel \
                java-17-openjdk-devel \
                maven \
                libayatana-appindicator3-devel \
                git \
                pkg-config
            ;;
        
        *)
            print_warning "Unsupported distribution: $DISTRO"
            print_warning "Please install dependencies manually:"
            echo "  - build-essential / base-devel"
            echo "  - libusb-1.0-dev"
            echo "  - openjdk-17-jdk (or newer)"
            echo "  - maven"
            echo "  - libayatana-appindicator3-dev"
            echo "  - git"
            echo "  - pkg-config"
            read -p "Press Enter when dependencies are installed..."
            ;;
    esac
    
    print_success "Dependencies installed"
}

# Build the C++ driver
build_driver() {
    print_step "Building G13 driver..."
    
    cd g13-driver/src
    
    if [ ! -f Makefile ]; then
        print_error "Makefile not found in g13-driver/src"
        exit 1
    fi
    
    make clean || true
    make
    
    if [ ! -f ../Linux-G13-Driver ]; then
        print_error "Driver binary not created"
        exit 1
    fi
    
    print_success "Driver built successfully"
    cd ../..
}

# Build the Java GUI
build_gui() {
    print_step "Building Java GUI..."
    
    cd g13-config-tool
    
    if [ ! -f pom.xml ]; then
        print_error "pom.xml not found in g13-config-tool"
        exit 1
    fi
    
    mvn clean package
    
    if [ ! -f target/Linux-G13-GUI.jar ]; then
        print_error "GUI JAR not created"
        exit 1
    fi
    
    print_success "GUI built successfully"
    cd ..
}

# Install driver to system locations
install_to_system() {
    print_step "Installing driver to system locations..."
    
    # Install driver binary
    sudo install -m 755 g13-driver/Linux-G13-Driver /usr/local/bin/g13-driver
    print_success "Installed driver to /usr/local/bin/g13-driver"
    
    # Install GUI to /opt
    sudo mkdir -p /opt/g13
    sudo cp g13-config-tool/target/Linux-G13-GUI.jar /opt/g13/
    sudo chmod 644 /opt/g13/Linux-G13-GUI.jar
    print_success "Installed GUI to /opt/g13/Linux-G13-GUI.jar"
}

# Setup udev rules
setup_udev() {
    print_step "Setting up udev rules..."
    
    # Add user to plugdev group if it exists
    if getent group plugdev > /dev/null; then
        sudo usermod -a -G plugdev $USER
        print_success "Added $USER to plugdev group"
    fi
    
    # Copy udev rules
    if [ -f g13-driver/src/udev/99-g13-plugdev.rules ]; then
        sudo cp g13-driver/src/udev/99-g13-plugdev.rules /etc/udev/rules.d/
        print_success "Installed udev rules"
    else
        print_warning "udev rules file not found, skipping"
    fi
    
    # Reload udev rules
    sudo udevadm control --reload-rules
    sudo udevadm trigger
    
    print_success "udev rules configured"
}

# Create configuration directory
setup_config_dir() {
    print_step "Creating configuration directory..."
    
    CONFIG_DIR="$HOME/.g13"
    if [ ! -d "$CONFIG_DIR" ]; then
        mkdir -p "$CONFIG_DIR"
        print_success "Created $CONFIG_DIR"
    else
        print_success "Configuration directory already exists"
    fi
}

# Setup systemd service (pointing to system location)
setup_systemd() {
    print_step "Setting up systemd service..."
    
    SERVICE_DIR="$HOME/.config/systemd/user"
    mkdir -p "$SERVICE_DIR"
    
    cat > "$SERVICE_DIR/g13-driver.service" << 'EOF'
[Unit]
Description=Logitech G13 Driver
After=graphical-session.target
Wants=graphical-session.target

[Service]
Type=simple
ExecStart=/usr/local/bin/g13-driver
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF
    
    print_success "Created systemd service"
    
    # Reload systemd
    systemctl --user daemon-reload
    systemctl --user enable g13-driver.service
    
    print_success "Systemd service enabled"
}

# Create desktop menu entries
create_menu_entries() {
    print_step "Creating desktop menu entries..."
    
    # Create scripts directory
    SCRIPT_BIN="$HOME/.local/bin"
    mkdir -p "$SCRIPT_BIN"
    
    # Create start script
    cat > "$SCRIPT_BIN/start-g13-driver" << 'EOFSTART'
#!/bin/bash

# Check if driver is already running
if systemctl --user is-active --quiet g13-driver.service; then
    if command -v kdialog &> /dev/null; then
        kdialog --title "G13 Driver" --msgbox "G13 Driver is already running!"
    elif command -v zenity &> /dev/null; then
        zenity --info --title="G13 Driver" --text="G13 Driver is already running!"
    else
        notify-send "G13 Driver" "Driver is already running!"
    fi
    exit 0
fi

# Check if G13 is connected
if ! lsusb | grep -q "046d:c21c"; then
    if command -v kdialog &> /dev/null; then
        kdialog --title "G13 Driver" --error "G13 device not detected!\n\nPlease check:\n• Is the G13 plugged in?\n• Try a different USB port\n• Check the USB cable"
    elif command -v zenity &> /dev/null; then
        zenity --error --title="G13 Driver" --text="G13 device not detected!\n\nPlease check:\n• Is the G13 plugged in?\n• Try a different USB port\n• Check the USB cable"
    else
        notify-send "G13 Driver Error" "G13 device not detected!"
    fi
    exit 1
fi

# Start the driver
systemctl --user start g13-driver.service

# Wait a moment for it to start
sleep 2

# Check if it started successfully
if systemctl --user is-active --quiet g13-driver.service; then
    if command -v kdialog &> /dev/null; then
        kdialog --title "G13 Driver" --passivepopup "G13 Driver started successfully!" 3
    elif command -v zenity &> /dev/null; then
        zenity --info --title="G13 Driver" --text="G13 Driver started successfully!" --timeout=3
    else
        notify-send "G13 Driver" "Driver started successfully!"
    fi
else
    ERROR_MSG="Failed to start G13 driver.\n\nCheck the logs with:\njournalctl --user -u g13-driver -n 20"
    
    if command -v kdialog &> /dev/null; then
        kdialog --title "G13 Driver Error" --error "$ERROR_MSG"
    elif command -v zenity &> /dev/null; then
        zenity --error --title="G13 Driver Error" --text="$ERROR_MSG"
    else
        notify-send "G13 Driver Error" "Failed to start driver"
    fi
    exit 1
fi
EOFSTART
    
    chmod +x "$SCRIPT_BIN/start-g13-driver"
    print_success "Created start script"
    
    # Create desktop entries directory
    DESKTOP_DIR="$HOME/.local/share/applications"
    mkdir -p "$DESKTOP_DIR"
    
    # Create "Start Driver" desktop entry
    cat > "$DESKTOP_DIR/g13-start-driver.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=G13 Start Driver
Comment=Start the Logitech G13 Driver
Exec=$SCRIPT_BIN/start-g13-driver
Icon=media-playback-start
Terminal=false
Categories=Settings;HardwareSettings;System;
Keywords=logitech;g13;gamepad;driver;start;
EOF
    
    print_success "Created 'G13 Start Driver' menu entry"
    
    # Create "Configuration" desktop entry
    cat > "$DESKTOP_DIR/g13-config.desktop" << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=G13 Configuration
Comment=Configure Logitech G13 Gamepad
Exec=java -jar /opt/g13/Linux-G13-GUI.jar
Icon=input-gaming
Terminal=false
Categories=Settings;HardwareSettings;
Keywords=logitech;g13;gamepad;macro;configure;
EOF
    
    print_success "Created 'G13 Configuration' menu entry"
    
    # Update desktop database
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
    fi
}

# Main installation function
main() {
    print_section "Logitech G13 Linux Driver Installation"
    
    # Check if running in correct directory
    if [ ! -d "g13-driver" ] || [ ! -d "g13-config-tool" ]; then
        print_error "This script must be run from the linux-g13-driver directory"
        print_error "Expected structure:"
        echo "  linux-g13-driver/"
        echo "  ├── g13-driver/"
        echo "  ├── g13-config-tool/"
        echo "  └── install.sh"
        exit 1
    fi
    
    print_step "Detecting Linux distribution..."
    detect_distro
    print_success "Detected: $PRETTY_NAME"
    
    install_dependencies
    build_driver
    build_gui
    install_to_system
    setup_config_dir
    setup_udev
    setup_systemd
    create_menu_entries
    
    print_section "Installation Complete!"
    echo ""
    echo -e "${GREEN}The G13 driver has been successfully installed to system locations.${NC}"
    echo ""
    echo "Installed files:"
    echo "  • Driver:  /usr/local/bin/g13-driver"
    echo "  • GUI:     /opt/g13/Linux-G13-GUI.jar"
    echo "  • Config:  ~/.g13/"
    echo "  • Service: ~/.config/systemd/user/g13-driver.service"
    echo ""
    echo "Menu entries created:"
    echo "  • G13 Start Driver      - Click to start the driver"
    echo "  • G13 Configuration     - Configure keys and macros"
    echo ""
    echo -e "${YELLOW}Important:${NC}"
    echo "  1. Reboot your system to apply all changes"
    echo "  2. After reboot, use 'G13 Start Driver' from menu to start"
    echo "  3. You can now DELETE the source folder - everything is installed!"
    echo ""
    echo "Commands:"
    echo "  systemctl --user start g13-driver     # Start driver"
    echo "  systemctl --user stop g13-driver      # Stop driver"
    echo "  systemctl --user status g13-driver    # Check status"
    echo ""
}

# Run main function
main
