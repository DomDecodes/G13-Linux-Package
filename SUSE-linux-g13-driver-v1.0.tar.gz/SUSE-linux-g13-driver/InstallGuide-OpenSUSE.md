# Logitech G13 Linux Driver - openSUSE Installation Guide

## Table of Contents
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Automated Installation](#automated-installation)
- [Manual Installation](#manual-installation)
- [Post-Installation](#post-installation)
- [Troubleshooting](#troubleshooting)
- [Uninstallation](#uninstallation)

## Overview

This guide covers installation of the Logitech G13 Linux driver on openSUSE Tumbleweed and openSUSE Leap.

**Important:** openSUSE requires special configuration compared to Ubuntu/Debian:
- The `plugdev` group must be created (doesn't exist by default)
- Users must be in both `plugdev` and `input` groups
- A udev rule for `/dev/uinput` must be created
- A **full system reboot** is required (logout/login is insufficient)

## Prerequisites

### System Requirements
- openSUSE Tumbleweed or openSUSE Leap 15.3+
- Java 17 or newer
- USB port for G13 device
- Internet connection for downloading dependencies

### Supported openSUSE Versions
- ✅ openSUSE Tumbleweed (tested)
- ✅ openSUSE Leap 15.5+
- ✅ openSUSE Leap 15.4
- ⚠️  Older versions may work but are untested

## Automated Installation

### Step 1: Download the Driver Package

```bash
cd ~/Downloads
# Extract the archive
unzip linux-g13-driver-opensuse.zip
cd linux-g13-driver
```

Or clone from GitHub:
```bash
git clone https://github.com/YOUR_USERNAME/linux-g13-driver.git
cd linux-g13-driver
```

### Step 2: Run the openSUSE Install Script

```bash
chmod +x install-opensuse.sh
./install-opensuse.sh
```

The script will:
1. ✅ Install all required packages with zypper
2. ✅ Create the `plugdev` group
3. ✅ Add you to `plugdev` and `input` groups
4. ✅ Build the C++ driver
5. ✅ Build the Java GUI
6. ✅ Install udev rules for G13 and uinput
7. ✅ Create systemd service for auto-start
8. ✅ Create desktop launcher

### Step 3: REBOOT

**CRITICAL:** After installation completes, you **MUST reboot** your system:

```bash
sudo reboot
```

⚠️ **Logging out and back in is NOT sufficient on openSUSE!**

### Step 4: Verify Installation

After reboot, check that the driver is running:

```bash
systemctl --user status g13-driver
```

You should see:
```
Active: active (running)
```

Check your G13 backlight - it should change from **white** to **grey/blue** when the driver connects.

## Manual Installation

If you prefer to install manually or the automated script fails:

### 1. Install Dependencies

```bash
sudo zypper refresh
sudo zypper install -y gcc gcc-c++ make libusb-1_0-devel java-17-openjdk-devel maven git
```

Optional (for system tray icon):
```bash
sudo zypper install -y libayatana-appindicator3-devel
```
or
```bash
sudo zypper install -y libappindicator3-devel
```

### 2. Create Required Groups

openSUSE doesn't have a `plugdev` group by default:

```bash
sudo groupadd plugdev
```

### 3. Add User to Groups

Replace `your-username` with your actual username:

```bash
sudo usermod -a -G plugdev your-username
sudo usermod -a -G input your-username
```

Verify:
```bash
getent group plugdev
getent group input
```

Both should show your username.

### 4. Build the Driver

```bash
cd ~/Downloads/linux-g13-driver/g13-driver/src
make clean
make
```

### 5. Build the GUI

```bash
cd ../../g13-config-tool
mvn clean package
cp target/Linux-G13-GUI.jar ../g13-driver/
```

### 6. Install udev Rules

For G13 device:
```bash
cd ../g13-driver/src
sudo cp udev/99-g13-plugdev.rules /etc/udev/rules.d/
```

For uinput device:
```bash
sudo tee /etc/udev/rules.d/99-uinput.rules > /dev/null << 'EOF'
KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"
EOF
```

Reload rules:
```bash
sudo udevadm control --reload-rules
sudo udevadm trigger
```

### 7. Create Systemd Service

```bash
mkdir -p ~/.config/systemd/user

cat > ~/.config/systemd/user/g13-driver.service << 'EOF'
[Unit]
Description=Logitech G13 Driver
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=/home/YOUR_USERNAME/Downloads/linux-g13-driver/g13-driver
ExecStart=/home/YOUR_USERNAME/Downloads/linux-g13-driver/g13-driver/Linux-G13-Driver
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF
```

Replace `YOUR_USERNAME` with your actual username, then:

```bash
systemctl --user daemon-reload
systemctl --user enable g13-driver.service
```

### 8. Create Desktop Launcher

```bash
mkdir -p ~/.local/share/applications

cat > ~/.local/share/applications/g13-config.desktop << 'EOF'
[Desktop Entry]
Name=G13 Configuration
Comment=Configure Logitech G13 Gameboard
Exec=bash -c "cd ~/Downloads/linux-g13-driver/g13-driver && java -jar Linux-G13-GUI.jar"
Icon=input-gaming
Terminal=false
Type=Application
Categories=Settings;HardwareSettings;
EOF

update-desktop-database ~/.local/share/applications/
```

### 9. REBOOT

```bash
sudo reboot
```

## Post-Installation

### Verify Installation

After reboot, run these checks:

#### 1. Check Group Memberships
```bash
id
```

You should see both `plugdev` and `input` in the groups list.

#### 2. Check Driver Status
```bash
systemctl --user status g13-driver
```

Should show: `Active: active (running)`

#### 3. Check G13 Device
```bash
lsusb | grep G13
```

Should show: `046d:c21c Logitech, Inc. G13 Advanced Gameboard`

#### 4. Check Permissions
```bash
ls -l /dev/uinput
```

Should show: `crw-rw---- 1 root input`

### Configure Your G13

1. **Launch the GUI:**
   - Search for "G13 Configuration" in your application menu
   - Or run: `java -jar ~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar`

2. **Change Backlight Color:**
   - In the GUI, click the color picker
   - Select your desired color
   - Click "Save" - the backlight should change immediately

3. **Assign Keys:**
   - Click a G-key on the GUI
   - Choose "Passthrough" or "Macro"
   - For passthrough: Select the keyboard key to emulate
   - For macro: Create or select a macro
   - Click "Save Current Profile"
   - Choose "Yes" to restart the driver

4. **Create Macros:**
   - Go to the "Macro Editor" tab
   - Select a macro slot (16-199 are user-editable)
   - Click "Clear & Record"
   - Press the key sequence you want
   - Click "Stop Recording"
   - Name your macro and save

### Using Multiple Profiles

The G13 has 4 profile buttons (M1, M2, M3, MR):
- M1 = Profile 0 (bindings-0.properties)
- M2 = Profile 1 (bindings-1.properties)
- M3 = Profile 2 (bindings-2.properties)
- MR = Profile 3 (bindings-3.properties)

Each profile can have different key assignments and colors!

## Troubleshooting

### Driver Won't Start

**Check logs:**
```bash
journalctl --user -u g13-driver -n 50
```

**Common errors:**

#### "Permission denied /dev/uinput"
Not in `input` group or didn't reboot:
```bash
getent group input  # Should show your username
id  # Should show 'input' in groups
```

If missing, add yourself and reboot:
```bash
sudo usermod -a -G input $USER
sudo reboot
```

#### "Device not found"
G13 not detected:
```bash
lsusb | grep G13
```

If not shown:
- Try a different USB port
- Unplug and replug the G13
- Check the USB cable

#### "Cannot claim interface"
Another driver is using the G13:
```bash
sudo dmesg | grep -i g13
```

Unplug and replug the G13.

### Backlight Stays White

If the backlight doesn't change from white, the driver isn't connecting:

```bash
systemctl --user status g13-driver
```

If it says "activating (auto-restart)" repeatedly, check the logs:
```bash
journalctl --user -u g13-driver -f
```

### No Tray Icon

The system tray icon requires `libayatana-appindicator` or `libappindicator`, which may not be available in openSUSE repositories. The driver works perfectly without it - just use the GUI from the application menu.

### Keys Not Working

**Known Issue:** Physical G-keys are numbered G1-G22, but config files use G0-G21.

When assigning keys in the GUI, remember that:
- Physical G1 = G0 in config
- Physical G2 = G1 in config
- etc.

The GUI handles this automatically, but if editing config files manually, subtract 1 from the physical key number.

### Start Driver Manually

If auto-start fails:
```bash
systemctl --user start g13-driver
```

To test driver without systemd:
```bash
cd ~/src/linux-g13-driver/g13-driver
./Linux-G13-Driver
```

Press Ctrl+C to stop.

### View Real-time Logs

```bash
journalctl --user -u g13-driver -f
```

Press Ctrl+C to stop.

## Uninstallation

### Remove Driver Files

```bash
rm -rf ~/src/linux-g13-driver
rm ~/.config/systemd/user/g13-driver.service
rm ~/.local/share/applications/g13-config.desktop
systemctl --user daemon-reload
```

### Remove udev Rules

```bash
sudo rm /etc/udev/rules.d/99-g13-plugdev.rules
sudo rm /etc/udev/rules.d/99-uinput.rules
sudo udevadm control --reload-rules
```

### Remove Group Memberships (Optional)

```bash
sudo gpasswd -d $USER plugdev
sudo gpasswd -d $USER input
```

Log out and back in for changes to take effect.

### Remove Groups (Optional)

If you created the plugdev group and want to remove it:
```bash
sudo groupdel plugdev
```

## Additional Resources

- **GitHub Repository:** [Link to your repo]
- **Report Issues:** [Link to issues page]
- **Original Driver:** https://github.com/ecraven/g13
- **Fork by LordBooker:** https://github.com/LordBooker/Linux-G13-Driver

## Credits

- Original driver by ecraven
- Fork with Ayatana support by LordBooker
- openSUSE adaptations and testing by community contributors

## License

GPL-3.0 License - See LICENSE file for details
