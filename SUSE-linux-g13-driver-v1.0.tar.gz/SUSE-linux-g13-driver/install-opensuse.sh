#!/bin/bash
#
# Logitech G13 Linux Driver - openSUSE Installation Script
# This script installs and configures the G13 driver with GUI on openSUSE
#

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Pretty print functions
print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
}

print_step() {
    echo -e "${GREEN}▶ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    print_error "Do not run this script as root!"
    print_warning "Run as your normal user. The script will ask for sudo when needed."
    exit 1
fi

print_header "Logitech G13 Linux Driver - openSUSE Installation"

# Detect distribution
print_step "Detecting Linux distribution..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    if [[ "$DISTRO" != *"suse"* ]]; then
        print_error "This script is for openSUSE only!"
        print_warning "Detected: $PRETTY_NAME"
        print_warning "Please use the standard install.sh for other distributions."
        exit 1
    fi
    print_success "Detected: $PRETTY_NAME"
else
    print_error "Cannot detect distribution"
    exit 1
fi

# Install dependencies
print_step "Installing dependencies with zypper..."

sudo zypper refresh

sudo zypper install -y \
    gcc gcc-c++ make \
    libusb-1_0-devel \
    java-17-openjdk-devel \
    maven \
    git

print_success "Core dependencies installed"

# Try to install AppIndicator library (optional, for tray icon)
print_step "Attempting to install AppIndicator library (optional)..."
if sudo zypper install -y libayatana-appindicator3-devel 2>/dev/null; then
    print_success "AppIndicator library installed - tray icon will be available"
elif sudo zypper install -y libappindicator3-devel 2>/dev/null; then
    print_success "AppIndicator library installed - tray icon will be available"
else
    print_warning "AppIndicator library not available in repositories"
    print_warning "Tray icon will not be available, but driver will work normally"
fi

# openSUSE-specific: Create plugdev group if it doesn't exist
print_step "Setting up device permissions..."
if ! getent group plugdev > /dev/null 2>&1; then
    print_step "Creating 'plugdev' group (doesn't exist by default on openSUSE)..."
    sudo groupadd plugdev
    print_success "plugdev group created"
else
    print_success "plugdev group already exists"
fi

# Add user to plugdev group
print_step "Adding user '$USER' to plugdev group..."
sudo usermod -a -G plugdev $USER
print_success "User added to plugdev group"

# openSUSE-specific: Add user to input group (required for uinput access)
print_step "Adding user '$USER' to input group (required for uinput)..."
sudo usermod -a -G input $USER
print_success "User added to input group"

# Verify group memberships were added
if getent group plugdev | grep -q "$USER" && getent group input | grep -q "$USER"; then
    print_success "Group memberships configured correctly"
else
    print_error "Failed to add user to required groups"
    exit 1
fi

# Set installation directory
INSTALL_DIR="$HOME/src/linux-g13-driver"

# Check if already installed
if [ -d "$INSTALL_DIR" ]; then
    print_warning "Installation directory already exists: $INSTALL_DIR"
    read -p "Remove and reinstall? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$INSTALL_DIR"
    else
        print_error "Installation cancelled"
        exit 1
    fi
fi

# Create src directory if needed
mkdir -p "$HOME/src"

# Clone repository (or copy if running from extracted archive)
print_step "Setting up source code..."

if [ -f "$(dirname "$0")/g13-driver/src/Makefile" ]; then
    # Running from extracted archive
    print_step "Copying files from archive..."
    cp -r "$(dirname "$0")" "$INSTALL_DIR"
else
    # Clone from GitHub
    print_step "Cloning from GitHub..."
    # TODO: Replace with actual GitHub URL
    git clone https://github.com/YOUR_USERNAME/linux-g13-driver.git "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"
print_success "Source code ready"

# Build C++ driver
print_step "Building C++ driver..."
cd g13-driver/src
make clean
make
print_success "Driver compiled"

# Build Java GUI
print_step "Building Java GUI..."
cd ../../g13-config-tool
mvn clean package
print_success "GUI compiled"

# Copy JAR to driver directory
print_step "Installing GUI..."
cp target/Linux-G13-GUI.jar ../g13-driver/
print_success "GUI installed"

# Install udev rules for G13 device
print_step "Installing udev rules for G13..."
cd ../g13-driver/src
sudo cp udev/99-g13-plugdev.rules /etc/udev/rules.d/
print_success "G13 udev rules installed"

# openSUSE-specific: Create udev rule for uinput device
print_step "Creating udev rule for uinput device..."
sudo tee /etc/udev/rules.d/99-uinput.rules > /dev/null << 'EOF'
# Allow input group to access uinput device
KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"
EOF
print_success "uinput udev rule created"

# Reload udev rules
print_step "Reloading udev rules..."
sudo udevadm control --reload-rules
sudo udevadm trigger
print_success "udev rules reloaded"

# Create systemd service
print_step "Creating systemd service..."
mkdir -p ~/.config/systemd/user

cat > ~/.config/systemd/user/g13-driver.service << EOF
[Unit]
Description=Logitech G13 Driver
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR/g13-driver
ExecStart=$INSTALL_DIR/g13-driver/Linux-G13-Driver
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable g13-driver.service
print_success "Systemd service created and enabled"

# Create desktop launcher
print_step "Creating desktop launcher..."
mkdir -p ~/.local/share/applications

cat > ~/.local/share/applications/g13-config.desktop << EOF
[Desktop Entry]
Name=G13 Configuration
Comment=Configure Logitech G13 Gameboard
Exec=java -jar $INSTALL_DIR/g13-driver/Linux-G13-GUI.jar
Icon=input-gaming
Terminal=false
Type=Application
Categories=Settings;HardwareSettings;
EOF

update-desktop-database ~/.local/share/applications/ 2>/dev/null || true
print_success "Desktop launcher created"

# Create convenience launcher script
print_step "Creating convenience launcher..."
cat > "$INSTALL_DIR/launch-gui.sh" << EOF
#!/bin/bash
cd "$INSTALL_DIR/g13-driver"
java -jar Linux-G13-GUI.jar
EOF
chmod +x "$INSTALL_DIR/launch-gui.sh"
print_success "Launcher script created"

# Create config directory
mkdir -p ~/.g13
print_success "Config directory created"

# Final instructions
print_header "Installation Complete!"

echo ""
print_warning "╔═══════════════════════════════════════════════════════════════╗"
print_warning "║  CRITICAL: You MUST REBOOT for everything to work!           ║"
print_warning "╚═══════════════════════════════════════════════════════════════╝"
echo ""

print_warning "Why REBOOT is required on openSUSE:"
echo "  - Group permissions (plugdev, input) need to take effect"
echo "  - uinput device permissions need to be applied"
echo "  - System tray icon needs proper initialization"
echo "  - Driver auto-start needs to be configured"
echo ""
print_warning "Logging out and back in is NOT sufficient on openSUSE!"
echo ""

print_step "After rebooting:"
echo "  1. Plug in your G13 (if not already connected)"
echo "  2. The G13 backlight should change from white to grey/blue"
echo "  3. Look for the G13 tray icon in your system tray (if AppIndicator installed)"
echo "  4. Launch 'G13 Configuration' from your application menu"
echo "  5. Configure your keys and macros"
echo ""

print_step "To verify the driver is running after reboot:"
echo "  systemctl --user status g13-driver"
echo ""
echo "  You should see: Active: active (running)"
echo ""

print_step "To view driver logs:"
echo "  journalctl --user -u g13-driver -f"
echo ""

print_step "If driver doesn't start after reboot, manually start it:"
echo "  systemctl --user start g13-driver"
echo ""

print_step "Known Issue - Key Indexing:"
echo "  Physical G-keys are numbered G1-G22 on the device,"
echo "  but config files use G0-G21 (subtract 1 from physical number)"
echo ""

print_success "Installation script completed successfully!"
echo ""
print_warning "═══════════════════════════════════════════════════════════════"
print_warning "  REBOOT NOW: sudo reboot"
print_warning "═══════════════════════════════════════════════════════════════"
