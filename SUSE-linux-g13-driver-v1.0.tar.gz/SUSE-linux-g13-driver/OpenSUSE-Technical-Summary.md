# openSUSE Package - Technical Summary

This document explains the differences between the standard G13 driver installation and the openSUSE-specific version.

## Key Differences from Ubuntu/Debian

### 1. Missing `plugdev` Group

**Problem:** openSUSE (both Tumbleweed and Leap) does not have a `plugdev` group by default, unlike Ubuntu/Debian.

**Solution:** The install script creates the group:
```bash
sudo groupadd plugdev
sudo usermod -a -G plugdev $USER
```

### 2. uinput Device Permissions

**Problem:** The driver needs write access to `/dev/uinput` to simulate keyboard input. On openSUSE, this device has restrictive permissions by default:
```
crw------- 1 root root /dev/uinput
```

**Solution:** 
- Add user to the `input` group
- Create a udev rule to change `/dev/uinput` permissions:

```bash
# Add user to input group
sudo usermod -a -G input $USER

# Create udev rule
sudo tee /etc/udev/rules.d/99-uinput.rules > /dev/null << 'EOF'
KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"
EOF

# Reload udev
sudo udevadm control --reload-rules
sudo udevadm trigger
```

### 3. Package Names

openSUSE uses different package names than Debian/Ubuntu:

| Package Type | Ubuntu/Debian | openSUSE |
|--------------|---------------|----------|
| Build tools | `build-essential` | `gcc gcc-c++ make` |
| libusb | `libusb-1.0-0-dev` | `libusb-1_0-devel` |
| Java | `openjdk-17-jdk` | `java-17-openjdk-devel` |
| Maven | `maven` | `maven` |
| AppIndicator | `libayatana-appindicator3-dev` | `libayatana-appindicator3-devel` (often unavailable) |

### 4. AppIndicator Library

**Problem:** The `libayatana-appindicator3-devel` package is often not available in openSUSE repositories.

**Solution:** The install script attempts to install it, but continues gracefully if unavailable:
```bash
if sudo zypper install -y libayatana-appindicator3-devel 2>/dev/null; then
    echo "Tray icon will be available"
elif sudo zypper install -y libappindicator3-devel 2>/dev/null; then
    echo "Tray icon will be available (older version)"
else
    echo "Tray icon not available - driver will work without it"
fi
```

The driver works perfectly without the tray icon - users can access the GUI from the application menu.

### 5. Group Changes Require Reboot

**Problem:** On openSUSE, group membership changes do not take effect after logging out and back in. A full reboot is required.

**Testing:**
```bash
# After adding user to groups
getent group input    # Shows user in group
id                    # Does NOT show 'input' until after reboot
```

**Solution:** The install script explicitly tells users to reboot, not just logout.

## File Structure

```
linux-g13-driver/
├── install.sh                    # Standard installer (Ubuntu/Debian/Arch/Fedora)
├── install-opensuse.sh           # openSUSE-specific installer
├── InstallGuide.md               # Standard installation guide
├── InstallGuide-OpenSUSE.md      # openSUSE-specific guide
├── ReadmeG13Package.md           # General README
├── README-OpenSUSE.md            # openSUSE quick start
└── ...
```

## Installation Workflow

### Standard Install (Ubuntu/Debian)
1. Install packages
2. Add user to `plugdev` (group already exists)
3. Build driver
4. Install udev rules
5. Create systemd service
6. **Logout/login** or reboot

### openSUSE Install
1. Install packages
2. **Create `plugdev` group**
3. Add user to `plugdev` AND `input` groups
4. Build driver
5. Install udev rules for G13 AND uinput
6. Create systemd service
7. **MUST REBOOT** (logout insufficient)

## Testing Checklist

After installation and reboot, verify:

```bash
# 1. User is in required groups
id | grep -E "(plugdev|input)"

# 2. uinput has correct permissions
ls -l /dev/uinput
# Should show: crw-rw---- 1 root input

# 3. G13 is detected
lsusb | grep G13

# 4. Driver is running
systemctl --user status g13-driver
# Should show: Active: active (running)

# 5. G13 backlight changed color
# Should be grey/blue, not white

# 6. Driver logs show success
journalctl --user -u g13-driver -n 20
# Should NOT show "Permission denied" or "uinput" errors
```

## Common Issues and Solutions

### Issue: "Permission denied /dev/uinput"

**Cause:** User not in `input` group or didn't reboot

**Fix:**
```bash
sudo usermod -a -G input $USER
sudo reboot
```

### Issue: "plugdev group doesn't exist"

**Cause:** Running standard install.sh instead of install-opensuse.sh

**Fix:**
```bash
sudo groupadd plugdev
sudo usermod -a -G plugdev $USER
```

### Issue: Driver keeps restarting

**Symptoms:**
```bash
systemctl --user status g13-driver
# Shows: activating (auto-restart)
```

**Diagnosis:**
```bash
journalctl --user -u g13-driver -n 20
# Look for error messages
```

**Common causes:**
- Permission errors → Check groups and uinput permissions
- Device not found → Check `lsusb | grep G13`
- Binary missing → Rebuild driver

### Issue: No tray icon

**Cause:** AppIndicator library not available in openSUSE repos

**Solution:** This is expected and normal. Use the application menu launcher instead.

## Package Manager Commands

### openSUSE (zypper)
```bash
# Refresh repositories
sudo zypper refresh

# Install packages
sudo zypper install -y package-name

# Search for packages
zypper search package-name

# Update system
sudo zypper update
```

## udev Rules

### G13 Device Rule (99-g13-plugdev.rules)
```
SUBSYSTEM=="usb", ATTRS{idVendor}=="046d", ATTRS{idProduct}=="c21c", MODE="0660", GROUP="plugdev"
```

### uinput Device Rule (99-uinput.rules)
```
KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"
```

Both rules must be in `/etc/udev/rules.d/` and loaded with:
```bash
sudo udevadm control --reload-rules
sudo udevadm trigger
```

## Building on openSUSE

The build process is identical to other distributions:

```bash
# C++ driver
cd g13-driver/src
make clean
make

# Java GUI
cd ../../g13-config-tool
mvn clean package
```

No openSUSE-specific build changes are needed.

## Systemd Service

The systemd service is identical across all distributions:

```ini
[Unit]
Description=Logitech G13 Driver
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=/path/to/g13-driver
ExecStart=/path/to/Linux-G13-Driver
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
```

## Version Detection

The install script detects openSUSE using `/etc/os-release`:

```bash
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    # For openSUSE: ID="opensuse-tumbleweed" or ID="opensuse-leap"
fi
```

## Tested Configurations

✅ **Confirmed Working:**
- openSUSE Tumbleweed (KDE Plasma 5.27)
- openSUSE Leap 15.5
- Java 17 OpenJDK
- Kernel 6.8.0

⚠️ **Not Tested (should work):**
- openSUSE Leap 15.4
- Java 11 (minimum version)
- Different desktop environments (GNOME, XFCE)

## Future Improvements

Potential enhancements for openSUSE package:

1. **One-Click Install (OCI):** Create an openSUSE OCI package for easier installation
2. **RPM Package:** Build an RPM for direct installation with zypper
3. **Auto-detect username:** Already implemented using `$USER`
4. **Better AppIndicator handling:** Compile without AppIndicator if not available
5. **SELinux support:** Add SELinux policies if needed

## Distribution-Specific Scripts

The package includes:

- `install.sh` - Multi-distro installer (Ubuntu, Debian, Fedora, Arch)
- `install-opensuse.sh` - openSUSE-specific installer
- Both detect and handle their respective distributions

Users should run the appropriate script for their system.

## Maintenance Notes

When updating the driver:

1. Test on both Tumbleweed and Leap
2. Verify group permissions still work
3. Check udev rules are applied correctly
4. Test with and without AppIndicator
5. Verify reboot requirement (not just logout)
6. Update documentation if any openSUSE-specific changes

## Contact

For openSUSE-specific issues:
- GitHub Issues: [Your repo URL]
- Email: [Your email]
- openSUSE Forums: Mention @your-username

---

**Document Version:** 1.0  
**Last Updated:** October 2025  
**Tested On:** openSUSE Tumbleweed, Kernel 6.8.0, KDE Plasma 5.27
