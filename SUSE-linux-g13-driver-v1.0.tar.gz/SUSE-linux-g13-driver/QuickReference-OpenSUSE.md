# G13 Driver Quick Reference - openSUSE Edition

## Installation

```bash
# Run the openSUSE installer
chmod +x install-opensuse.sh
./install-opensuse.sh

# THEN REBOOT (required!)
sudo reboot
```

## Essential Commands

### Driver Control
```bash
# Check status
systemctl --user status g13-driver

# Start driver
systemctl --user start g13-driver

# Stop driver
systemctl --user stop g13-driver

# Restart driver
systemctl --user restart g13-driver

# Enable auto-start (should already be enabled)
systemctl --user enable g13-driver

# Disable auto-start
systemctl --user disable g13-driver
```

### Logs and Diagnostics
```bash
# View real-time logs
journalctl --user -u g13-driver -f

# View last 50 log entries
journalctl --user -u g13-driver -n 50

# Check if G13 is connected
lsusb | grep G13

# Check your groups
id

# Check uinput permissions
ls -l /dev/uinput
```

### Launch GUI
```bash
# From application menu
Search: "G13 Configuration"

# Or from command line
java -jar ~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar
```

## Verification Checklist

After reboot, verify everything:

```bash
# 1. Check you're in required groups (should see 'plugdev' and 'input')
id

# 2. Check uinput permissions (should be 'crw-rw---- 1 root input')
ls -l /dev/uinput

# 3. Check G13 is detected (should see '046d:c21c')
lsusb | grep G13

# 4. Check driver is running (should see 'Active: active (running)')
systemctl --user status g13-driver

# 5. G13 backlight should be grey/blue, not white!
```

## Troubleshooting

### Driver Won't Start
```bash
# Check logs for errors
journalctl --user -u g13-driver -n 50

# Common error: "Permission denied /dev/uinput"
# Solution: Make sure you REBOOTED after installation

# Check if you're in input group
id | grep input

# If not, add yourself and reboot
sudo usermod -a -G input $USER
sudo reboot
```

### Backlight Stays White
```bash
# Driver isn't connecting. Check status:
systemctl --user status g13-driver

# If it says "activating (auto-restart)" - it's crashing
# Check logs:
journalctl --user -u g13-driver -f
```

### Permission Errors
```bash
# Fix uinput permissions manually
sudo chown root:input /dev/uinput
sudo chmod 0660 /dev/uinput

# Add yourself to groups
sudo usermod -a -G plugdev $USER
sudo usermod -a -G input $USER

# REBOOT (required!)
sudo reboot
```

### G13 Not Detected
```bash
# Check USB
lsusb | grep -i logitech

# Try different USB port
# Unplug and replug G13

# Check USB messages
sudo dmesg | tail -20
```

## Configuration Files

### Profiles (Key Bindings)
```
~/.g13/bindings-0.properties  # M1 button
~/.g13/bindings-1.properties  # M2 button
~/.g13/bindings-2.properties  # M3 button
~/.g13/bindings-3.properties  # MR button
```

### Macros
```
~/.g13/macro-0.properties      # Predefined (read-only)
~/.g13/macro-16.properties     # User macros (editable)
~/.g13/macro-199.properties    # (up to 200 total)
```

### Driver Files
```
~/src/linux-g13-driver/g13-driver/Linux-G13-Driver    # Binary
~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar   # GUI
~/.config/systemd/user/g13-driver.service              # Service
```

## Common Tasks

### Change Backlight Color
```bash
# Option 1: Use GUI
java -jar ~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar
# Click color picker, select color, click Save

# Option 2: Edit config manually
nano ~/.g13/bindings-0.properties
# Add line: color=255,0,0
# Restart driver: systemctl --user restart g13-driver
```

### Assign a Key
```bash
# Use GUI - it's much easier!
java -jar ~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar
# Click G-key, select action, click Save
```

### Create a Macro
```bash
# Use GUI Macro Editor tab
# 1. Select macro slot (16-199)
# 2. Click "Clear & Record"
# 3. Press your key sequence
# 4. Click "Stop Recording"
# 5. Name it and save
```

### Switch Profiles
```bash
# Press M1, M2, M3, or MR button on G13
# Each profile has different key assignments and colors
```

## Key Indexing Issue

**IMPORTANT:** Physical G-keys are numbered G1-G22, but configs use G0-G21.

**Physical → Config:**
- G1 → G0
- G2 → G1
- G22 → G21

The GUI handles this automatically!

## Emergency Commands

### Force Stop Driver
```bash
systemctl --user stop g13-driver
killall Linux-G13-Driver
```

### Reset Config
```bash
# Backup first!
mv ~/.g13 ~/.g13.backup

# Restart driver - will create defaults
systemctl --user restart g13-driver
```

### Test Driver Manually
```bash
# Stop the service
systemctl --user stop g13-driver

# Run manually to see errors
cd ~/src/linux-g13-driver/g13-driver
./Linux-G13-Driver

# Press Ctrl+C to stop
# Restart service:
systemctl --user start g13-driver
```

### Rebuild Driver
```bash
cd ~/src/linux-g13-driver/g13-driver/src
make clean
make

# Restart service
systemctl --user restart g13-driver
```

## openSUSE-Specific Notes

### Group Management
```bash
# Check group membership
getent group plugdev
getent group input

# Add user to groups (replace 'username')
sudo usermod -a -G plugdev username
sudo usermod -a -G input username

# Changes require REBOOT on openSUSE!
```

### udev Rules
```bash
# Reload udev rules
sudo udevadm control --reload-rules
sudo udevadm trigger

# Check if rules exist
ls -l /etc/udev/rules.d/99-g13-plugdev.rules
ls -l /etc/udev/rules.d/99-uinput.rules
```

### Package Management
```bash
# Update packages
sudo zypper update

# Search for package
zypper search package-name

# Install package
sudo zypper install package-name

# Remove package
sudo zypper remove package-name
```

## Getting Help

### Check Documentation
```bash
# Detailed guide
cat ~/src/linux-g13-driver/InstallGuide-OpenSUSE.md

# README
cat ~/src/linux-g13-driver/README-OpenSUSE.md
```

### Gather Diagnostic Info
```bash
# System info
cat /etc/os-release

# Group membership
id

# Device detection
lsusb | grep G13

# Permissions
ls -l /dev/uinput

# Driver status
systemctl --user status g13-driver

# Recent logs
journalctl --user -u g13-driver -n 100 > ~/g13-logs.txt
```

### Report Issue
Include in your bug report:
1. openSUSE version (`cat /etc/os-release`)
2. Output of `id`
3. Output of `ls -l /dev/uinput`
4. Driver logs (`journalctl --user -u g13-driver -n 100`)
5. What you were trying to do
6. What actually happened

## Uninstall

```bash
# Stop and disable driver
systemctl --user stop g13-driver
systemctl --user disable g13-driver

# Remove files
rm -rf ~/src/linux-g13-driver
rm ~/.config/systemd/user/g13-driver.service
rm ~/.local/share/applications/g13-config.desktop

# Remove udev rules
sudo rm /etc/udev/rules.d/99-g13-plugdev.rules
sudo rm /etc/udev/rules.d/99-uinput.rules
sudo udevadm control --reload-rules

# Remove groups (optional)
sudo gpasswd -d $USER plugdev
sudo gpasswd -d $USER input

# Logout/login for changes
```

---

**Quick Start:** `./install-opensuse.sh` → `sudo reboot` → Done!

**Most Important:** REBOOT after installation (logout is not enough on openSUSE)

**Help:** See `InstallGuide-OpenSUSE.md` for detailed troubleshooting
