# Logitech G13 Linux Driver for openSUSE

A Linux userspace driver for the Logitech G13 gameboard with GUI configuration tool, specifically adapted for openSUSE Tumbleweed and Leap.

![G13 Gameboard](docs/g13-device.png)

## ⚠️ Important for openSUSE Users

openSUSE requires special configuration that differs from Ubuntu/Debian:

- ✅ Creates the `plugdev` group (doesn't exist by default)
- ✅ Adds user to both `plugdev` and `input` groups
- ✅ Creates udev rule for `/dev/uinput` device
- ✅ **Requires full system REBOOT** (logout/login insufficient)

**Use `install-opensuse.sh` instead of the standard `install.sh`!**

## Quick Start

### 1. Install

```bash
cd linux-g13-driver
chmod +x install-opensuse.sh
./install-opensuse.sh
```

### 2. REBOOT

```bash
sudo reboot
```

⚠️ **REBOOT IS REQUIRED** - logging out is not enough on openSUSE!

### 3. Configure

After reboot:
1. Open "G13 Configuration" from your application menu
2. Click a G-key and assign a keyboard key or macro
3. Change the backlight color
4. Click "Save Current Profile"

**That's it!** Your G13 is ready to use.

## What Gets Installed

- **Driver binary:** `~/src/linux-g13-driver/g13-driver/Linux-G13-Driver`
- **Java GUI:** `~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar`
- **Config files:** `~/.g13/bindings-*.properties` and `~/.g13/macro-*.properties`
- **Systemd service:** Auto-starts driver on login
- **Desktop launcher:** "G13 Configuration" in application menu

## Features

- ✅ All 22 G-keys fully programmable
- ✅ 4 profile modes (M1, M2, M3, MR)
- ✅ RGB backlight control
- ✅ Macro recording and playback
- ✅ Joystick as arrow keys or absolute positioning
- ✅ Java-based GUI for easy configuration
- ✅ System tray icon (if AppIndicator available)
- ✅ Auto-start on login

## Verify Installation

After rebooting, check everything is working:

```bash
# Should show 'active (running)'
systemctl --user status g13-driver

# Should show the G13 device
lsusb | grep G13

# Should show you're in the required groups
id | grep -E "(plugdev|input)"

# Check driver logs
journalctl --user -u g13-driver -f
```

**G13 backlight should change from white to grey/blue when driver connects!**

## Requirements

### System
- openSUSE Tumbleweed or Leap 15.3+
- Java 17 or newer
- USB port for G13

### Dependencies
Automatically installed by the script:
- gcc, g++, make
- libusb-1.0
- Java 17 OpenJDK
- Maven
- AppIndicator library (optional, for tray icon)

## Configuration Files

### Key Bindings (Profiles)
- `~/.g13/bindings-0.properties` - M1 button (Profile 0)
- `~/.g13/bindings-1.properties` - M2 button (Profile 1)
- `~/.g13/bindings-2.properties` - M3 button (Profile 2)
- `~/.g13/bindings-3.properties` - MR button (Profile 3)

### Macros
- `~/.g13/macro-0.properties` through `macro-15.properties` - Pre-defined macros (read-only)
- `~/.g13/macro-16.properties` through `macro-199.properties` - User-editable macros

## Known Issues

### Key Indexing Off-by-One Bug

Physical G-keys are numbered **G1-G22** on the device, but the driver uses **G0-G21** in config files.

**Example:** Physical G1 button → G0 in config file

The GUI handles this automatically, but if you're editing config files manually, remember to subtract 1 from the physical key number.

### No System Tray Icon

The system tray icon requires `libayatana-appindicator` or `libappindicator`, which may not be available in openSUSE repositories. The driver works perfectly without it - just launch the GUI from your application menu.

## Troubleshooting

### Driver won't start after reboot?

```bash
# Check logs for errors
journalctl --user -u g13-driver -n 50

# Manually start the driver
systemctl --user start g13-driver

# Check if you're in the required groups
id
```

You should see both `plugdev` and `input` in your groups. If not, you didn't reboot after installation.

### Backlight stays white?

The driver isn't connecting to the G13. Check:

```bash
# Is the G13 detected?
lsusb | grep G13

# Is the driver running?
systemctl --user status g13-driver

# Check for errors
journalctl --user -u g13-driver -f
```

### Permission errors?

```bash
# Check uinput permissions
ls -l /dev/uinput

# Should show: crw-rw---- 1 root input

# If not, fix it:
sudo chown root:input /dev/uinput
sudo chmod 0660 /dev/uinput

# Then reboot
sudo reboot
```

## Essential Commands

```bash
# Check driver status
systemctl --user status g13-driver

# Start driver
systemctl --user start g13-driver

# Stop driver
systemctl --user stop g13-driver

# Restart driver
systemctl --user restart g13-driver

# View logs
journalctl --user -u g13-driver -f

# Check if G13 is connected
lsusb | grep G13

# Launch configuration GUI
java -jar ~/src/linux-g13-driver/g13-driver/Linux-G13-GUI.jar
```

## Documentation

- **[Detailed Installation Guide](InstallGuide-OpenSUSE.md)** - Complete step-by-step instructions
- **[Changelog](changelog.md)** - Version history and changes
- **[General README](ReadmeG13Package.md)** - Overview for all distributions

## Support

### Getting Help

1. Check the [InstallGuide-OpenSUSE.md](InstallGuide-OpenSUSE.md) troubleshooting section
2. View driver logs: `journalctl --user -u g13-driver -f`
3. Open an issue on GitHub with:
   - Your openSUSE version (`cat /etc/os-release`)
   - Driver logs
   - Output of `systemctl --user status g13-driver`

### Reporting Issues

When reporting issues, please include:
- openSUSE version (Tumbleweed or Leap X.X)
- Output of `id` (shows your groups)
- Output of `ls -l /dev/uinput`
- Driver logs from `journalctl --user -u g13-driver -n 100`

## Uninstall

```bash
# Stop and disable the driver
systemctl --user stop g13-driver
systemctl --user disable g13-driver

# Remove files
rm -rf ~/src/linux-g13-driver
rm ~/.config/systemd/user/g13-driver.service
rm ~/.local/share/applications/g13-config.desktop

# Remove udev rules
sudo rm /etc/udev/rules.d/99-g13-plugdev.rules
sudo rm /etc/udev/rules.d/99-uinput.rules
sudo udevadm control --reload-rules

# Remove group memberships (optional)
sudo gpasswd -d $USER plugdev
sudo gpasswd -d $USER input
```

Log out and back in for group changes to take effect.

## Credits

- **Original driver:** [ecraven/g13](https://github.com/ecraven/g13)
- **Ayatana fork:** [LordBooker/Linux-G13-Driver](https://github.com/LordBooker/Linux-G13-Driver)
- **openSUSE adaptations:** Community contributors

## License

GPL-3.0 License - See LICENSE file for details

---

**Need help?** Check [InstallGuide-OpenSUSE.md](InstallGuide-OpenSUSE.md) for detailed troubleshooting!
